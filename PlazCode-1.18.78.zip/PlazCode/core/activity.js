// SPDX-License-Identifier: GPL-3.0-or-later
const PlazCodeActivity = (() => {
  function create(changed = () => {}) {
    let current, sequence = 0;
    const groups = [];
    function sync(busy, chat, now = Date.now()) {
      if (current && current.chat !== chat) finish(now);
      if (busy && !current) {
        current = { id: String(++sequence), chat, started: now, ended: 0, expanded: true, events: [] };
        groups.push(current);
      } else if (!busy && current) finish(now);
      changed();
    }
    function finish(now = Date.now()) { if (current) { current.ended = now; current.expanded = false; current = null; } }
    function step(name, detail = '') {
      if (!current) return;
      current.events.push({ name: String(name), detail: String(detail).slice(0, 300) });
      if (current.events.length > 100) current.events.shift(); changed();
    }
    function toggle(id) { const group = groups.find(group => group.id === id); if (group) { group.expanded = !group.expanded; changed(); } }
    function list(chat) { return groups.filter(group => group.chat === chat); }
    function label(group, now = Date.now()) {
      const seconds = Math.floor(((group.ended || now) - group.started) / 1000);
      return `${group.ended ? 'Worked' : 'Working'} for ${Math.floor(seconds / 60)}m ${seconds % 60}s`;
    }
    return { sync, finish, step, toggle, list, label, active: () => current };
  }
  return { create };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = PlazCodeActivity;
