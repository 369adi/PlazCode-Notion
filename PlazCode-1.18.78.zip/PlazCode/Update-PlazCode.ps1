# PlazCode updater, Windows PowerShell 5.1. Accepts an optional local release ZIP.
param([string]$ZipPath)
$ErrorActionPreference = 'Stop'
$install = $PSScriptRoot
$stage = Join-Path ([IO.Path]::GetTempPath()) ('PlazCode-update-' + [guid]::NewGuid())
$backup = Join-Path $stage 'backup'
$written = New-Object 'System.Collections.Generic.List[string]'
$stopped = $false
try {
    Write-Host 'PlazCode updater' -ForegroundColor Yellow
    $current = [version](Get-Content (Join-Path $install 'manifest.json') -Raw | ConvertFrom-Json).version
    $source = Get-Content (Join-Path $install 'update-source.json') -Raw | ConvertFrom-Json
    if (!$source.feedUrl) { $source.feedUrl = "https://raw.githubusercontent.com/stoveez/PlazCodeneww/main/latest.json" }
    New-Item $stage -ItemType Directory | Out-Null
    if (!$ZipPath -and $source.feedUrl) {
        if ($source.feedUrl -notmatch '^https://') { throw 'The release feed must use HTTPS.' }
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $release = Invoke-RestMethod -Uri $source.feedUrl -TimeoutSec 30
        $latest = [version]$release.version
        if ($latest -le $current) { Write-Host "Already up to date ($current)."; exit 0 }
        if ($release.url -notmatch '^https://' -or $release.sha256 -notmatch '^[a-fA-F0-9]{64}$') { throw 'Invalid release feed: expected version, HTTPS url and SHA256.' }
        $ZipPath = Join-Path $stage 'release.zip'
        Write-Host "Downloading $latest..."
        Invoke-WebRequest -UseBasicParsing -Uri $release.url -OutFile $ZipPath -TimeoutSec 180
        if ((Get-FileHash $ZipPath -Algorithm SHA256).Hash -ne $release.sha256) { throw 'Download checksum mismatch. No installed files were changed.' }
    }
    if (!$ZipPath) {
        Write-Host 'No release feed configured. Select a downloaded PlazCode release ZIP.'
        Add-Type -AssemblyName System.Windows.Forms
        $picker = New-Object System.Windows.Forms.OpenFileDialog
        $picker.Filter = 'PlazCode release (*.zip)|*.zip'
        if ($picker.ShowDialog() -ne 'OK') { Write-Host 'Update cancelled.'; exit 0 }
        $ZipPath = $picker.FileName
    }
    $ZipPath = (Resolve-Path -LiteralPath $ZipPath).Path
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $unpacked = Join-Path $stage 'unpacked'
    $archive = [IO.Compression.ZipFile]::OpenRead($ZipPath)
    try {
        foreach ($entry in $archive.Entries) {
            $name = $entry.FullName.Replace('\','/')
            if ($name -notmatch '^PlazCode/' -or $name -match '(^|/)\.\.(/|$)|:|(^|/)(logs|target|\.git)(/|$)') { throw "Unexpected ZIP entry: $name" }
            $destination = [IO.Path]::GetFullPath((Join-Path $unpacked $name))
            if (!$destination.StartsWith([IO.Path]::GetFullPath($unpacked) + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid ZIP path.' }
        }
    } finally { $archive.Dispose() }
    [IO.Compression.ZipFile]::ExtractToDirectory($ZipPath, $unpacked)
    $package = Join-Path $unpacked 'PlazCode'
    $next = [version](Get-Content (Join-Path $package 'manifest.json') -Raw | ConvertFrom-Json).version
    if ($next -le $current) { Write-Host "Already up to date ($current; selected package $next)."; exit 0 }
    foreach ($required in @('PlazCode.exe','WebView2Loader.dll','background.js','core/main.js','Start-PlazCode-Agent.cmd')) {
        if (!(Test-Path -LiteralPath (Join-Path $package $required))) { throw "Release is missing $required." }
    }
    if ($release -and $next -ne $latest) { throw 'Release feed version does not match the downloaded package.' }
    $files = @(Get-ChildItem $package -File -Recurse | Where-Object { $_.Name -notin @('config.json','update-source.json') })
    # Back up overwritten files before stopping the app or modifying the installation.
    foreach ($file in $files) {
        $relative = $file.FullName.Substring($package.Length + 1)
        $old = Join-Path $install $relative
        if (Test-Path -LiteralPath $old) {
            $copy = Join-Path $backup $relative
            New-Item (Split-Path $copy) -ItemType Directory -Force | Out-Null
            Copy-Item -LiteralPath $old -Destination $copy
        }
    }
    # Stop only agent processes belonging to this installation. Leave Studio running.
    Get-CimInstance Win32_Process | Where-Object {
        $_.Name -in @('PlazCode.exe','plazcode-agent.exe') -and $_.ExecutablePath -and
        (Split-Path $_.ExecutablePath) -eq $install
    } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop }
    $stopped = $true
    foreach ($file in $files) {
        $relative = $file.FullName.Substring($package.Length + 1)
        $target = Join-Path $install $relative
        $written.Add($relative)
        New-Item (Split-Path $target) -ItemType Directory -Force | Out-Null
        Copy-Item -LiteralPath $file.FullName -Destination $target -Force
    }
    Start-Process -FilePath (Join-Path $install 'PlazCode.exe') -WorkingDirectory $install
    Write-Host "Updated $current -> $next. Reload the extension, then refresh open AI chat tabs." -ForegroundColor Green
} catch {
    foreach ($relative in $written) {
        $target = Join-Path $install $relative
        $saved = Join-Path $backup $relative
        try {
            if (Test-Path -LiteralPath $saved) { Copy-Item -LiteralPath $saved -Destination $target -Force }
            else { Remove-Item -LiteralPath $target -Force -ErrorAction SilentlyContinue }
        } catch { Write-Host "Could not restore $relative. Backup retained at $backup" -ForegroundColor Red }
    }
    if ($stopped) { Start-Process -FilePath (Join-Path $install 'PlazCode.exe') -WorkingDirectory $install -ErrorAction SilentlyContinue }
    Write-Host ('Update failed: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host "Recovery files: $stage"
    exit 1
}
# Keep backup for recovery; downloaded/extracted staging files can be removed.
Remove-Item (Join-Path $stage 'unpacked') -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $stage 'release.zip') -Force -ErrorAction SilentlyContinue
