use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, HashMap};
use std::path::PathBuf;
use std::process::Stdio;
use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader, Lines};
use tokio::process::{Child, ChildStdin, ChildStdout, Command};

#[cfg(windows)]
use std::os::windows::process::CommandExt;

#[cfg(windows)]
const CREATE_NO_WINDOW: u32 = 0x0800_0000;

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct ServerSpec {
    pub command: String,
    #[serde(default)]
    pub args: Vec<String>,
    #[serde(default)]
    pub env: HashMap<String, String>,
}

#[derive(Clone, Debug, Serialize, Deserialize, Default)]
pub struct McpConfig {
    #[serde(rename = "mcpServers", default)]
    pub servers: BTreeMap<String, ServerSpec>,
}

#[derive(Clone, Debug)]
pub struct CatalogEntry {
    pub id: &'static str,
    pub name: &'static str,
    pub description: &'static str,
    pub command: &'static str,
    pub args: &'static [&'static str],
}

#[derive(Clone, Debug, Serialize)]
pub struct ServerSummary {
    pub id: String,
    pub name: String,
    pub alive: bool,
    pub tools: usize,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub error: Option<String>,
}

pub fn catalog() -> Vec<CatalogEntry> {
    vec![
        CatalogEntry {
            id: "blender",
            name: "Blender",
            description: "3D scene, mesh and asset tools through Blender MCP.",
            command: "uvx",
            args: &["blender-mcp"],
        },
        CatalogEntry {
            id: "context7",
            name: "Context7",
            description: "Library and framework documentation lookup.",
            command: "npx",
            args: &["-y", "@upstash/context7-mcp"],
        },
        CatalogEntry {
            id: "fetch",
            name: "Fetch",
            description: "Fetch and read web resources through an MCP server.",
            command: "uvx",
            args: &["mcp-server-fetch"],
        },
        CatalogEntry {
            id: "git",
            name: "Git",
            description: "Local Git repository inspection and operations.",
            command: "uvx",
            args: &["mcp-server-git"],
        },
        CatalogEntry {
            id: "memory",
            name: "Memory",
            description: "Local graph-style memory tools for agent sessions.",
            command: "npx",
            args: &["-y", "@modelcontextprotocol/server-memory"],
        },
        CatalogEntry {
            id: "thinking",
            name: "Sequential Thinking",
            description: "Structured step-by-step reasoning utilities.",
            command: "npx",
            args: &["-y", "@modelcontextprotocol/server-sequential-thinking"],
        },
    ]
}

pub fn config_path() -> PathBuf {
    std::env::current_exe()
        .ok()
        .and_then(|p| p.parent().map(|d| d.join("config.json")))
        .unwrap_or_else(|| PathBuf::from("config.json"))
}

pub fn read_config() -> McpConfig {
    let path = config_path();
    let mut cfg = std::fs::read_to_string(path)
        .ok()
        .and_then(|raw| serde_json::from_str::<McpConfig>(&raw).ok())
        .unwrap_or_default();
    cfg.servers.entry("roblox".to_string()).or_insert_with(|| ServerSpec {
        command: "launch_studio_mcp.py".to_string(),
        args: Vec::new(),
        env: HashMap::new(),
    });
    cfg
}

pub fn write_config(cfg: &McpConfig) -> anyhow::Result<()> {
    let path = config_path();
    let tmp = path.with_extension("json.tmp");
    std::fs::write(&tmp, serde_json::to_vec_pretty(cfg)?)?;
    if path.exists() {
        std::fs::remove_file(&path)?;
    }
    std::fs::rename(tmp, path)?;
    Ok(())
}

pub fn is_enabled(id: &str) -> bool {
    read_config().servers.contains_key(id)
}

pub fn set_catalog_enabled(id: &str, enabled: bool) -> anyhow::Result<()> {
    let entry = catalog().into_iter().find(|e| e.id == id)
        .ok_or_else(|| anyhow::anyhow!("unknown catalog server '{id}'"))?;
    let mut cfg = read_config();
    if enabled {
        cfg.servers.insert(id.to_string(), ServerSpec {
            command: entry.command.to_string(),
            args: entry.args.iter().map(|v| (*v).to_string()).collect(),
            env: HashMap::new(),
        });
    } else {
        cfg.servers.remove(id);
    }
    write_config(&cfg)
}

pub fn add_server(id: &str, spec: ServerSpec) -> anyhow::Result<()> {
    let id = id.trim();
    anyhow::ensure!(!id.is_empty(), "server id is required");
    anyhow::ensure!(id != "roblox", "the Roblox server cannot be replaced");
    anyhow::ensure!(!spec.command.trim().is_empty(), "server command is required");
    let mut cfg = read_config();
    cfg.servers.insert(id.to_string(), spec);
    write_config(&cfg)
}

pub fn remove_server(id: &str) -> anyhow::Result<()> {
    let id = id.trim();
    anyhow::ensure!(id != "roblox", "the Roblox server cannot be removed");
    let mut cfg = read_config();
    anyhow::ensure!(cfg.servers.remove(id).is_some(), "server '{id}' is not configured");
    write_config(&cfg)
}

struct AddonRuntime {
    id: String,
    spec: ServerSpec,
    child: Option<Child>,
    stdin: Option<ChildStdin>,
    stdout: Option<Lines<BufReader<ChildStdout>>>,
    next_id: u64,
    tools: Vec<serde_json::Value>,
    last_error: Option<String>,
    stderr: std::sync::Arc<std::sync::Mutex<std::collections::VecDeque<String>>>,
    stderr_task: Option<tokio::task::JoinHandle<()>>,
    initialized: bool,
}

impl AddonRuntime {
    fn new(id: String, spec: ServerSpec) -> Self {
        Self {
            id,
            spec,
            child: None,
            stdin: None,
            stdout: None,
            next_id: 1,
            tools: Vec::new(),
            last_error: None,
            stderr: Default::default(),
            stderr_task: None,
            initialized: false,
        }
    }

    fn same_spec(&self, spec: &ServerSpec) -> bool {
        &self.spec == spec
    }

    fn child_alive(&mut self) -> bool {
        match self.child.as_mut() {
            Some(child) => matches!(child.try_wait(), Ok(None)),
            None => false,
        }
    }

    async fn reset(&mut self) {
        if let Some(child) = self.child.as_mut() {
            #[cfg(windows)]
            if let Some(pid) = child.id() {
                let _ = std::process::Command::new("taskkill")
                    .args(["/F", "/T", "/PID", &pid.to_string()])
                    .creation_flags(CREATE_NO_WINDOW)
                    .output();
            }
            let _ = child.kill().await;
        }
        if let Some(task) = self.stderr_task.take() { task.abort(); }
        self.stderr.lock().unwrap_or_else(|error| error.into_inner()).clear();
        self.initialized = false;
        self.child = None;
        self.stdin = None;
        self.stdout = None;
        self.tools.clear();
        self.next_id = 1;
    }

    fn command(&self) -> anyhow::Result<Command> {
        #[cfg(windows)]
        {
            let low = self.spec.command.to_ascii_lowercase();
            let app = config_path().parent().unwrap_or_else(|| std::path::Path::new(".")).to_path_buf();
            if low == "npx" || low == "uvx" {
                let cache = std::env::var_os("LOCALAPPDATA").map(PathBuf::from)
                    .map(|base| base.join("PlazCode").join("runtimes"));
                let mut roots = vec![app.join("runtimes").join("node"), app.join("runtimes").join("uv")];
                if let Some(cache) = cache {
                    roots.push(cache.join(if low == "npx" { "node-22.22.0" } else { "uv-0.12.21" }));
                }
                if let Some(profile) = std::env::var_os("USERPROFILE") {
                    let profile = PathBuf::from(profile);
                    roots.push(profile.join(".local").join("bin"));
                    roots.push(profile.join(".cargo").join("bin"));
                    let node_root = profile.join("PlazCodeWorkspace").join("node");
                    if let Ok(entries) = std::fs::read_dir(node_root) {
                        roots.extend(entries.flatten().map(|entry| entry.path()));
                    }
                }
                if let Some(programs) = std::env::var_os("ProgramFiles") {
                    roots.push(PathBuf::from(programs).join("nodejs"));
                }
                if let Some(path) = self.spec.env.get("PATH").map(std::ffi::OsString::from).or_else(|| std::env::var_os("PATH")) {
                    roots.extend(std::env::split_paths(&path));
                }
                for root in roots {
                    let binary = root.join(if low == "npx" { "node.exe" } else { "uvx.exe" });
                    let cli = root.join("node_modules").join("npm").join("bin").join("npx-cli.js");
                    if !binary.is_file() || (low == "npx" && !cli.is_file()) { continue; }
                    let mut cmd = Command::new(binary);
                    if low == "npx" { cmd.arg(cli); }
                    cmd.args(&self.spec.args).envs(&self.spec.env);
                    let mut paths = vec![root];
                    if let Some(path) = self.spec.env.get("PATH").map(std::ffi::OsString::from).or_else(|| std::env::var_os("PATH")) {
                        paths.extend(std::env::split_paths(&path));
                    }
                    cmd.env("PATH", std::env::join_paths(paths)?);
                    cmd.current_dir(&app).creation_flags(CREATE_NO_WINDOW);
                    return Ok(cmd);
                }
                anyhow::bail!("[{}] {} runtime unavailable; first-use setup requires internet access.", self.id, low);
            }
            if low.ends_with(".cmd") || low.ends_with(".bat") {
                let mut cmd = Command::new("cmd");
                cmd.arg("/D").arg("/C").arg(&self.spec.command).args(&self.spec.args);
                cmd.envs(&self.spec.env);
                cmd.creation_flags(CREATE_NO_WINDOW);
                return Ok(cmd);
            }
        }
        let mut cmd = Command::new(&self.spec.command);
        cmd.args(&self.spec.args).envs(&self.spec.env);
        #[cfg(windows)]
        cmd.creation_flags(CREATE_NO_WINDOW);
        Ok(cmd)
    }

    async fn ensure(&mut self) -> anyhow::Result<()> {
        if self.initialized && self.child_alive() && self.stdin.is_some() && self.stdout.is_some() {
            return Ok(());
        }
        self.reset().await;
        let command = self.command();
        #[cfg(windows)]
        let command = match command {
            Err(error) if matches!(self.spec.command.to_ascii_lowercase().as_str(), "npx" | "uvx") => {
                let app = config_path().parent().unwrap_or_else(|| std::path::Path::new(".")).to_path_buf();
                let script = app.join("Setup-Mcp-Runtime.ps1");
                anyhow::ensure!(script.is_file(), "[{}] Runtime setup script missing: {} ({error})", self.id, script.display());
                tracing::info!("[{}] Preparing {} runtime for first use; download is cached for later launches", self.id, self.spec.command);
                let mut setup = Command::new("powershell.exe");
                setup.args(["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File"])
                    .arg(script).arg("-Runtime").arg(self.spec.command.to_ascii_lowercase())
                    .creation_flags(CREATE_NO_WINDOW).kill_on_drop(true);
                let output = tokio::time::timeout(std::time::Duration::from_secs(300), setup.output()).await
                    .map_err(|_| anyhow::anyhow!("[{}] Runtime setup timed out; check internet access and retry", self.id))??;
                anyhow::ensure!(output.status.success(), "[{}] Runtime setup failed: {}", self.id,
                    String::from_utf8_lossy(&output.stderr).chars().take(4000).collect::<String>());
                tracing::info!("[{}] Runtime setup completed", self.id);
                self.command()
            }
            other => other,
        };
        let mut cmd = command?;
        cmd.stdin(Stdio::piped()).stdout(Stdio::piped()).stderr(Stdio::piped()).kill_on_drop(true);
        let mut child = cmd.spawn().map_err(|e| anyhow::anyhow!("[{}] could not start '{}': {e}", self.id, self.spec.command))?;
        if let Some(stderr) = child.stderr.take() {
            let tail = self.stderr.clone();
            self.stderr_task = Some(tokio::spawn(async move {
                let mut lines = BufReader::new(stderr).lines();
                while let Ok(Some(line)) = lines.next_line().await {
                    let mut tail = tail.lock().unwrap_or_else(|error| error.into_inner());
                    if tail.len() == 12 { tail.pop_front(); }
                    tail.push_back(line.chars().take(1000).collect());
                }
            }));
        }
        self.stdin = child.stdin.take();
        self.stdout = child.stdout.take().map(|s| BufReader::new(s).lines());
        self.child = Some(child);
        self.request("initialize", serde_json::json!({
            "protocolVersion": "2025-06-18",
            "capabilities": {},
            "clientInfo": {"name": "PlazCode", "version": env!("CARGO_PKG_VERSION")}
        })).await?;
        self.notify("notifications/initialized", serde_json::json!({})).await?;
        self.initialized = true;
        self.last_error = None;
        Ok(())
    }

    async fn notify(&mut self, method: &str, params: serde_json::Value) -> anyhow::Result<()> {
        let line = serde_json::json!({"jsonrpc":"2.0","method":method,"params":params}).to_string() + "\n";
        self.stdin.as_mut().ok_or_else(|| anyhow::anyhow!("MCP stdin unavailable"))?.write_all(line.as_bytes()).await?;
        self.stdin.as_mut().ok_or_else(|| anyhow::anyhow!("MCP stdin unavailable"))?.flush().await?;
        Ok(())
    }

    async fn request(&mut self, method: &str, params: serde_json::Value) -> anyhow::Result<serde_json::Value> {
        let request_id = self.next_id;
        self.next_id += 1;
        let line = serde_json::json!({"jsonrpc":"2.0","id":request_id,"method":method,"params":params}).to_string() + "\n";
        let stdin = self.stdin.as_mut().ok_or_else(|| anyhow::anyhow!("MCP stdin unavailable"))?;
        stdin.write_all(line.as_bytes()).await?;
        stdin.flush().await?;
        let stdout = self.stdout.as_mut().ok_or_else(|| anyhow::anyhow!("MCP stdout unavailable"))?;
        loop {
            let line = tokio::time::timeout(std::time::Duration::from_secs(120), stdout.next_line()).await
                .map_err(|_| anyhow::anyhow!("[{}] MCP request timed out: {method}", self.id))??
                .ok_or_else(|| anyhow::anyhow!("[{}] MCP server exited while handling {method}: {}", self.id,
                    self.stderr.lock().unwrap_or_else(|error| error.into_inner()).iter().cloned().collect::<Vec<_>>().join(" | ")))?;
            let Ok(message) = serde_json::from_str::<serde_json::Value>(&line) else { continue; };
            if message.get("id").and_then(|v| v.as_u64()) != Some(request_id) {
                continue;
            }
            if let Some(error) = message.get("error") {
                anyhow::bail!("[{}] {method} failed: {error}", self.id);
            }
            return message.get("result").cloned().ok_or_else(|| anyhow::anyhow!("[{}] {method} returned no result", self.id));
        }
    }

    async fn list_tools(&mut self) -> anyhow::Result<Vec<serde_json::Value>> {
        self.ensure().await?;
        let result = self.request("tools/list", serde_json::json!({})).await?;
        self.tools = result.get("tools").and_then(|v| v.as_array()).cloned().unwrap_or_default();
        Ok(self.tools.clone())
    }

    async fn call_tool(&mut self, name: &str, args: serde_json::Value) -> anyhow::Result<(String, Vec<serde_json::Value>)> {
        self.ensure().await?;
        let result = self.request("tools/call", serde_json::json!({"name":name,"arguments":args})).await?;
        let is_error = result.get("isError").and_then(|v| v.as_bool()).unwrap_or(false);
        let mut texts = Vec::new();
        let mut images = Vec::new();
        if let Some(items) = result.get("content").and_then(|v| v.as_array()) {
            for item in items {
                if let Some(text) = item.get("text").and_then(|v| v.as_str()) {
                    texts.push(text.to_string());
                }
                if item.get("type").and_then(|v| v.as_str()) == Some("image") {
                    if let Some(data) = item.get("data").and_then(|v| v.as_str()) {
                        images.push(serde_json::json!({
                            "mimeType": item.get("mimeType").and_then(|v| v.as_str()).unwrap_or("image/png"),
                            "data": data
                        }));
                    }
                }
            }
        }
        let text = texts.join("\n");
        if is_error {
            anyhow::bail!("{}", if text.is_empty() { result.to_string() } else { text });
        }
        Ok((text, images))
    }
}

pub struct AddonManager {
    runtimes: HashMap<String, AddonRuntime>,
}

impl AddonManager {
    pub fn new() -> Self {
        Self { runtimes: HashMap::new() }
    }

    async fn sync_config(&mut self) {
        let cfg = read_config();
        let wanted: HashMap<String, ServerSpec> = cfg.servers.into_iter()
            .filter(|(id, _)| id != "roblox")
            .collect();

        let stale: Vec<String> = self.runtimes.keys()
            .filter(|id| !wanted.contains_key(*id))
            .cloned()
            .collect();
        for id in stale {
            if let Some(mut runtime) = self.runtimes.remove(&id) {
                runtime.reset().await;
            }
        }

        for (id, spec) in wanted {
            let replace = self.runtimes.get(&id).map(|r| !r.same_spec(&spec)).unwrap_or(true);
            if replace {
                if let Some(mut old) = self.runtimes.remove(&id) {
                    old.reset().await;
                }
                self.runtimes.insert(id.clone(), AddonRuntime::new(id, spec));
            }
        }
    }

    pub async fn reset_all(&mut self) {
        for runtime in self.runtimes.values_mut() {
            runtime.reset().await;
        }
        self.runtimes.clear();
    }

    pub async fn list_tools(&mut self) -> (Vec<serde_json::Value>, Vec<ServerSummary>) {
        self.sync_config().await;
        let mut tools = Vec::new();
        let mut summaries = Vec::new();
        let ids: Vec<String> = self.runtimes.keys().cloned().collect();
        for id in ids {
            let Some(runtime) = self.runtimes.get_mut(&id) else { continue; };
            match runtime.list_tools().await {
                Ok(server_tools) => {
                    for mut tool in server_tools {
                        let Some(real) = tool.get("name").and_then(|v| v.as_str()).map(str::to_string) else { continue; };
                        tool["name"] = serde_json::Value::String(format!("{id}__{real}"));
                        if let Some(desc) = tool.get("description").and_then(|v| v.as_str()).map(str::to_string) {
                            tool["description"] = serde_json::Value::String(format!("[{id}] {desc}"));
                        }
                        tool["server"] = serde_json::Value::String(id.clone());
                        tools.push(tool);
                    }
                    summaries.push(ServerSummary {
                        id: id.clone(),
                        name: id.clone(),
                        alive: true,
                        tools: runtime.tools.len(),
                        error: None,
                    });
                }
                Err(error) => {
                    runtime.last_error = Some(error.to_string());
                    summaries.push(ServerSummary {
                        id: id.clone(),
                        name: id.clone(),
                        alive: false,
                        tools: 0,
                        error: runtime.last_error.clone(),
                    });
                }
            }
        }
        summaries.sort_by(|a, b| a.id.cmp(&b.id));
        (tools, summaries)
    }

    pub async fn call_tool(&mut self, advertised: &str, args: serde_json::Value) -> anyhow::Result<(String, Vec<serde_json::Value>)> {
        self.sync_config().await;
        let (id, real) = advertised.split_once("__")
            .ok_or_else(|| anyhow::anyhow!("invalid add-on tool name '{advertised}'"))?;
        let runtime = self.runtimes.get_mut(id)
            .ok_or_else(|| anyhow::anyhow!("MCP server '{id}' is not configured"))?;
        runtime.call_tool(real, args).await
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::{BufRead, Write};

    #[test]
    #[ignore]
    fn stdio_fixture() {
        let mut initialized = false;
        for line in std::io::stdin().lock().lines() {
            let line = line.unwrap();
            let Ok(message) = serde_json::from_str::<serde_json::Value>(&line) else { continue; };
            let method = message["method"].as_str().unwrap_or("");
            if method == "notifications/initialized" { initialized = true; continue; }
            let result = match method {
                "initialize" if std::env::var("PLAZCODE_TEST_REJECT").is_ok() => {
                    println!("{}", serde_json::json!({"jsonrpc":"2.0","id":message["id"],"error":{"code":-32603,"message":"fixture initialization rejected"}}));
                    std::io::stdout().flush().unwrap();
                    continue;
                }
                "initialize" => serde_json::json!({"protocolVersion":"2025-06-18","capabilities":{"tools":{}}}),
                "tools/list" if initialized => serde_json::json!({"tools":[{"name":"echo","inputSchema":{"type":"object"}}]}),
                "tools/call" if initialized => serde_json::json!({"content":[{"type":"text","text":message["params"]["arguments"]["text"]}]}),
                _ => panic!("request before initialized notification"),
            };
            println!("{}", serde_json::json!({"jsonrpc":"2.0","id":message["id"],"result":result}));
            std::io::stdout().flush().unwrap();
        }
    }

    fn fixture(reject: bool) -> AddonRuntime {
        let mut env = HashMap::new();
        if reject { env.insert("PLAZCODE_TEST_REJECT".into(), "1".into()); }
        AddonRuntime::new("fixture".into(), ServerSpec {
            command: std::env::current_exe().unwrap().to_string_lossy().into_owned(),
            args: vec!["--ignored".into(), "--exact".into(), "mcp_addons::tests::stdio_fixture".into(), "--nocapture".into()],
            env,
        })
    }

    #[tokio::test]
    async fn stdio_handshake_and_tool_call() {
        let mut runtime = fixture(false);
        let tools = runtime.list_tools().await.unwrap();
        assert_eq!(tools[0]["name"], "echo");
        let pid = runtime.child.as_ref().unwrap().id();
        let (text, images) = runtime.call_tool("echo", serde_json::json!({"text":"hello"})).await.unwrap();
        assert_eq!(text, "hello");
        assert!(images.is_empty());
        assert_eq!(pid, runtime.child.as_ref().unwrap().id());
        runtime.reset().await;
        assert!(!runtime.initialized);
        assert!(!runtime.child_alive());
    }

    #[tokio::test]
    async fn failed_initialize_is_never_reused_as_ready() {
        let mut runtime = fixture(true);
        assert!(runtime.list_tools().await.unwrap_err().to_string().contains("fixture initialization rejected"));
        assert!(!runtime.initialized);
        assert!(runtime.list_tools().await.unwrap_err().to_string().contains("fixture initialization rejected"));
        runtime.reset().await;
    }
}
