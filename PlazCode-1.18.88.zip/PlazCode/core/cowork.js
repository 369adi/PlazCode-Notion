// SPDX-License-Identifier: GPL-3.0-or-later
const PlazCodeCowork = (() => {
  function create({ context, ready, send, changed = () => {} }) {
    let enabled = false, paused = false, reason = "", nextId = 1, sending = false;
    const pending = [];
    const snapshot = () => ({ enabled, paused, reason, sending,
      pending: pending.map(({ id, text, status }) => ({ id, preview: text.slice(0, 180), status })) });
    const notify = () => changed(snapshot());
    function pause(message = "Paused. Resume when you are ready.") {
      paused = true; reason = message; notify();
    }
    function setEnabled(value) { enabled = value === true; notify(); }
    function enqueue(text) {
      if (!enabled) return { ok: false, error: "Turn Co-work on first." };
      if (typeof text !== "string" || !text.trim()) return { ok: false, error: "Enter a request first." };
      if (text.length > 100000 || pending.length >= 50) return { ok: false, error: "The queue is full or this request is too long." };
      const id = nextId++;
      pending.push({ id, text, context: context(), status: "queued" }); notify();
      return { ok: true, id };
    }
    function remove(id) {
      const index = pending.findIndex(item => item.id === Number(id));
      if (index < 0 || pending[index].status === "sending") return { ok: false, error: "This request has already started." };
      pending.splice(index, 1); notify(); return { ok: true };
    }
    function resume() {
      if (!enabled) return { ok: false, error: "Turn Co-work on first." };
      if (pending.some(item => item.context !== context())) return { ok: false, error: "Return to the original chat and engine, or remove its queued requests." };
      if (pending.some(item => item.status === "unconfirmed")) return { ok: false, error: "Check the chat and remove the unconfirmed request before resuming." };
      paused = false; reason = ""; notify(); return { ok: true };
    }
    async function take() {
      if (!enabled || paused || sending || !pending.length || !ready()) return null;
      const item = pending[0];
      if (item.context !== context()) { pause("Chat or engine changed. Return to the original chat to resume."); return null; }
      sending = true; item.status = "sending"; notify();
      try {
        const base = await send(item.text);
        pending.splice(pending.indexOf(item), 1);
        return { base };
      } catch (error) {
        item.status = "unconfirmed";
        pause("Delivery could not be confirmed. Check the chat before removing this entry and resuming.");
        return null;
      } finally { sending = false; notify(); }
    }
    return { snapshot, setEnabled, enqueue, remove, pause, resume, take };
  }
  return { create };
})();
if (typeof module !== "undefined" && module.exports) module.exports = PlazCodeCowork;
