// SPDX-License-Identifier: GPL-3.0-or-later
const PlazCodeActivity = (() => {
  function create(changed = () => {}) {
    let current, sequence = 0;
    const groups = [];
    function sync(busy, chat, now = Date.now()) {
      if (current && current.chat !== chat) finish(now);
      if (busy && !current) {
        current = { id: String(++sequence), chat, started: now, ended: 0, expanded: true, events: [] };
        groups.push(current);
        if (groups.length > 60) groups.splice(0, groups.length - 60);
      } else if (!busy && current) finish(now);
      changed();
    }
    function finish(now = Date.now()) { if (current) { current.ended = now; current.expanded = false; current = null; } }
    function step(name, detail = '') {
      if (!current) return;
      current.events.push({ name: String(name), detail: String(detail).slice(0, 300) });
      if (current.events.length > 100) current.events.shift(); changed();
    }
    function toggle(id) { const group = groups.find(group => group.id === id); if (group) { group.expanded = !group.expanded; changed(); } }
    function list(chat) { return groups.filter(group => group.chat === chat); }
    function label(group, now = Date.now()) {
      const seconds = Math.floor(((group.ended || now) - group.started) / 1000);
      return `${group.ended ? 'Worked' : 'Working'} for ${Math.floor(seconds / 60)}m ${seconds % 60}s`;
    }
    return { sync, finish, step, toggle, list, label, active: () => current };
  }
  function renderer({label,toggle,mount}) {
    const views = new Map();
    function sync(groups, findItem) {
      const alive = new Set(groups.map(group => group.id));
      for (const [id, view] of views) if (!alive.has(id)) { view.binding?.dispose?.();view.node.remove();views.delete(id); }
      for (const group of groups) {
        const item = findItem(group);let view = views.get(group.id);
        if (!item || !item.isConnected) { if (view) view.node.hidden = true;continue; }
        if (!view) {
          const node = document.createElement('section');node.className='rs-chat-activity';
          const heading=document.createElement('button');heading.type='button';heading.className='rs-chat-activity-heading';
          const icon=document.createElement('span');icon.className='rs-chat-activity-icon';icon.setAttribute('aria-hidden','true');
          const title=document.createElement('span');const arrow=document.createElement('span');arrow.className='rs-chat-activity-arrow';arrow.setAttribute('aria-hidden','true');
          const body=document.createElement('div');body.className='rs-chat-activity-body';body.id='rs-chat-activity-'+group.id;
          heading.setAttribute('aria-controls',body.id);heading.append(icon,title,arrow);heading.onclick=()=>toggle(group.id);node.append(heading,body);
          view={node,heading,icon,title,arrow,body};views.set(group.id,view);
        }
        if (view.item !== item || !view.node.isConnected) { view.binding?.dispose?.();view.item=item;view.binding=mount(item,view.node); }
        view.node.hidden = !view.binding;
        view.node.dataset.done=group.ended?'1':'0';view.title.textContent=label(group);view.icon.textContent=group.ended?'✓':'◌';
        view.heading.setAttribute('aria-expanded',String(group.expanded));view.arrow.textContent=group.expanded?'⌄':'›';view.body.hidden=!group.expanded;
        const signature=group.expanded ? JSON.stringify([group.ended,group.events]) : 'collapsed';
        if (signature!==view.signature) {
          view.signature=signature;view.body.replaceChildren();
          if (!group.expanded) continue;
          if (!group.events.length) { const row=document.createElement('div');row.textContent=group.ended?'No tools were used in this response.':'Waiting for the AI response…';view.body.appendChild(row); }
          for (const event of group.events) { const row=document.createElement('div');const name=document.createElement('strong');name.textContent=event.name;const detail=document.createElement('span');detail.textContent=event.detail;row.append(name,detail);view.body.appendChild(row); }
        }
        view.binding?.place?.();
      }
    }
    return {sync};
  }
  return { create, renderer };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = PlazCodeActivity;
