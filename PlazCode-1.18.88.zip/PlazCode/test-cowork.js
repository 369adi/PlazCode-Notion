const assert = require('node:assert/strict');
const Cowork = require('./core/cowork.js');
(async () => {
  let context = 'chat-a|roblox', ready = true, calls = [], hold;
  const queue = Cowork.create({ context: () => context, ready: () => ready,
    send: async text => { calls.push(text); return calls.length; } });
  assert.equal(queue.enqueue('first').ok, false);
  queue.setEnabled(true);
  ready = false;
  queue.enqueue('first'); queue.enqueue('second'); queue.enqueue('third');
  assert.equal(await queue.take(), null); assert.deepEqual(calls, []);
  ready = true;
  assert.deepEqual(await queue.take(), { base: 1 });
  assert.deepEqual(await queue.take(), { base: 2 });
  assert.deepEqual(calls, ['first', 'second']);
  queue.setEnabled(false); assert.equal(await queue.take(), null);
  assert.equal(queue.snapshot().pending.length, 1);
  queue.setEnabled(true); queue.pause('Stopped'); assert.equal(await queue.take(), null);
  assert.equal(queue.resume().ok, true); await queue.take();
  const literal = '  Exact C:\\Game\\foo.lua\n"Name" ${Player}  ';
  queue.enqueue(literal); await queue.take(); assert.equal(calls.at(-1), literal);
  const removed = queue.enqueue('remove me'); queue.remove(removed.id);
  assert.equal(await queue.take(), null);
  queue.enqueue('original chat'); context = 'chat-b|roblox';
  assert.equal(await queue.take(), null); assert.equal(queue.resume().ok, false);
  context = 'chat-a|local'; assert.equal(queue.resume().ok, false);
  context = 'chat-a|roblox'; queue.resume(); await queue.take();
  const deferred = Cowork.create({ context: () => context, ready: () => true,
    send: () => new Promise(resolve => { hold = resolve; }) });
  deferred.setEnabled(true); const item = deferred.enqueue('once');
  const first = deferred.take(); assert.equal(await deferred.take(), null);
  assert.equal(deferred.remove(item.id).ok, false);
  deferred.pause('Stopped while sending'); hold(9); await first;
  assert.equal(deferred.snapshot().pending.length, 0);
  assert.equal(deferred.snapshot().paused, true);
  let failures = 0;
  const uncertain = Cowork.create({ context: () => context, ready: () => true,
    send: async () => { failures++; throw Error('Unconfirmed'); } });
  uncertain.setEnabled(true); const failed = uncertain.enqueue('maybe sent'); uncertain.enqueue('next');
  assert.equal(await uncertain.take(), null);
  assert.equal(uncertain.snapshot().pending[0].status, 'unconfirmed');
  assert.equal(uncertain.resume().ok, false); assert.equal(await uncertain.take(), null);
  assert.equal(failures, 1);
  uncertain.remove(failed.id); assert.equal(uncertain.resume().ok, true);
  console.log('Co-work: ordering, off, stop, context, literals, remove, concurrency and uncertain delivery passed.');
})().catch(error => { console.error(error); process.exitCode = 1; });
