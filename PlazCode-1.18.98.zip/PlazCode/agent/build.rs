use std::{env, path::PathBuf};

fn main() {
    let root = PathBuf::from(env::var_os("CARGO_MANIFEST_DIR").unwrap());
    let parent = root.parent().unwrap();
    let nested = parent.join("PlazCode-Extension");
    let extension = if nested.join("manifest.json").is_file() { nested } else { parent.to_owned() };
    println!("cargo:rustc-env=PLAZCODE_EXTENSION_ROOT={}", extension.display());
    println!("cargo:rerun-if-changed=build.rs");
    for name in ["memory.js", "task-center.js", "templates.js", "version.js", "media.js"] {
        println!("cargo:rerun-if-changed={}", extension.join("core").join(name).display());
    }
    println!("cargo:rerun-if-changed={}", parent.join("PlazCode-Extension/manifest.json").display());
}
