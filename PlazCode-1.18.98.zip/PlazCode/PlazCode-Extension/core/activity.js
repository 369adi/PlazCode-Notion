// SPDX-License-Identifier: GPL-3.0-or-later
const PlazCodeActivity = (() => {
  function create(changed = () => {}) {
    let current, sequence = 0;
    const groups = [];
    function sync(busy, chat, now = Date.now()) {
      if (current && current.chat !== chat) finish(now);
      if (busy && !current) {
        current = { id: String(++sequence), chat, started: now, ended: 0, expanded: true, events: [], messages: [], revision: 0, omitted: 0 };
        groups.push(current);
        if (groups.length > 60) groups.splice(0, groups.length - 60);
      } else if (!busy && current) finish(now);
      changed();
    }
    function finish(now = Date.now()) { if (current) { current.ended = now; current.expanded = false; current = null; } }
    function step(name, detail = '') {
      if (!current) return;
      if (!current.ended) current.expanded = true;
      current.events.push({ name: String(name), detail: String(detail).slice(0, 300) });
      if (current.events.length > 100) current.events.shift(); changed();
    }
    function record(id, key, role, text) {
      const group = groups.find(group => group.id === id); if (!group) return;
      text = String(text || '');
      const oversized = text.length > 200000;
      if (oversized) text = '[This reply exceeds the desktop detail limit. Read the full reply in its original browser chat.]';
      const known = group.messages.find(message => message.key === key);
      if (known && known.text === text && known.role === role) return;
      if (oversized) group.omitted++;
      if (known) { known.text = text; known.role = role; }
      else group.messages.push({key,role,text});
      group.revision++;
      function size(g) { return g.messages.reduce((sum,message)=>sum+message.text.length,0); }
      while (group.messages.length > 120 || size(group) > 200000) { group.messages.shift();group.omitted++;group.revision++; }
      let total = groups.reduce((sum,g)=>sum+size(g),0);
      for (const old of groups) while (total > 800000 && old.messages.length) { total-=old.messages.shift().text.length;old.omitted++;old.revision++; }
    }
    function removeMessage(id, key) {
      const group = groups.find(group => group.id === id); if (!group) return;
      const at = group.messages.findIndex(message=>message.key===key);
      if (at >= 0) { group.messages.splice(at,1);group.revision++; }
    }
    function read(id, revision) {
      const group = groups.find(group=>group.id===id); if (!group) return {ok:false,error:'This activity is no longer retained. Open its original browser chat.'};
      if (revision === group.revision) return {ok:true,not_modified:true,revision:group.revision};
      return {ok:true,revision:group.revision,messages:group.messages.map(message=>({...message})),omitted:group.omitted};
    }
    function toggle(id) { const group = groups.find(group => group.id === id); if (group) { group.expanded = !group.expanded; changed(); } }
    function list(chat) { return groups.filter(group => group.chat === chat); }
    function label(group, now = Date.now()) {
      const seconds = Math.floor(((group.ended || now) - group.started) / 1000);
      return `${group.ended ? 'Worked' : 'Working'} for ${Math.floor(seconds / 60)}m ${seconds % 60}s`;
    }
    return { sync, finish, step, record, removeMessage, read, toggle, list, label, active: () => current };
  }
  function exempt(text, calls = []) {
    const clean = String(text || '').replace(/[`*#]/g, '').trim();
    return /^(?:PLAZCODE_READY|PlazCode is ready)[.!]?$/i.test(clean) ||
      /^Output of '(?:list_commands|list_tools)'/.test(clean) ||
      /^⟦RS-SYS⟧/.test(clean) ||
      (calls.length > 0 && calls.every(call => /^(?:list_commands|list_tools)$/.test(call.tool)));
  }
  function renderer({label,toggle,mount}) {
    const views = new Map();
    function sync(groups, findItem) {
      const alive = new Set(groups.map(group => group.id));
      for (const [id, view] of views) if (!alive.has(id)) { view.binding?.dispose?.();view.node.remove();views.delete(id); }
      for (const group of groups) {
        const item = findItem(group);let view = views.get(group.id);
        if (!item || !item.isConnected) { if (view) view.node.hidden = true;continue; }
        if (!view) {
          const node = document.createElement('section');node.className='rs-chat-activity';
          const heading=document.createElement('button');heading.type='button';heading.className='rs-chat-activity-heading';
          const icon=document.createElement('span');icon.className='rs-chat-activity-icon';icon.setAttribute('aria-hidden','true');
          const title=document.createElement('span');const arrow=document.createElement('span');arrow.className='rs-chat-activity-arrow';arrow.setAttribute('aria-hidden','true');arrow.innerHTML='<svg width="14" height="14" viewBox="0 0 12 12" fill="none"><path d="M4 2L8 6L4 10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
          const body=document.createElement('div');body.className='rs-chat-activity-body';body.id='rs-chat-activity-'+group.id;
          heading.setAttribute('aria-controls',body.id);heading.append(icon,title,arrow);heading.onclick=()=>toggle(group.id);node.append(heading,body);
          view={node,heading,icon,title,arrow,body};views.set(group.id,view);
        }
        if (view.item !== item || !view.node.isConnected) { view.binding?.dispose?.();view.item=item;view.binding=mount(item,view.node); }
        view.node.hidden = !view.binding;
        view.node.dataset.done=group.ended?'1':'0';view.title.textContent=label(group);view.icon.textContent=group.ended?'✓':'◌';
        view.heading.setAttribute('aria-expanded',String(group.expanded));view.arrow.style.transform=group.expanded?'rotate(90deg)':'rotate(0deg)';view.body.hidden=!group.expanded;
        const signature=group.expanded ? JSON.stringify([group.ended,group.events]) : 'collapsed';
        if (signature!==view.signature) {
          view.signature=signature;view.body.replaceChildren();
          if (!group.expanded) continue;
          if (!group.ended && !group.events.length && !group.messages.length) { const row=document.createElement('div');row.textContent='Waiting for the AI response…';view.body.appendChild(row); }
          for (const event of group.events) { const row=document.createElement('div');const name=document.createElement('strong');name.textContent=event.name;const detail=document.createElement('span');detail.textContent=event.detail;row.append(name,detail);view.body.appendChild(row); }
        }
        view.binding?.place?.();
      }
    }
    return {sync};
  }
  return { create, renderer, exempt };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = PlazCodeActivity;
