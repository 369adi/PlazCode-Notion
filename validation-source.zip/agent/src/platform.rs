use std::path::{Path,PathBuf};
pub fn installation_root_at(executable:&Path)->PathBuf {
    for ancestor in executable.ancestors().skip(1) {
        if ancestor.extension().is_some_and(|extension|extension=="app") {
            return ancestor.parent().unwrap_or_else(||Path::new(".")).to_owned();
        }
    }
    executable.parent().unwrap_or_else(||Path::new(".")).to_owned()
}
pub fn installation_root()->PathBuf {std::env::current_exe().ok().map(|path|installation_root_at(&path)).unwrap_or_default()}
#[cfg(target_os="macos")]
pub fn configuration_root()->PathBuf {PathBuf::from(std::env::var_os("HOME").unwrap_or_default()).join("Library/Application Support/PlazCode")}
#[cfg(test)]mod tests{use super::*;#[test]fn bundle_root_is_outside_signed_app(){assert_eq!(installation_root_at(Path::new("/Applications/PlazCode/PlazCode.app/Contents/MacOS/PlazCode")),Path::new("/Applications/PlazCode"));assert_eq!(installation_root_at(Path::new("/opt/PlazCode/PlazCode")),Path::new("/opt/PlazCode"));}}
