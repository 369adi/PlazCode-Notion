#!/bin/bash
set -euo pipefail
root=$(cd -- "$(dirname -- "$0")" && pwd)
[[ -d "$root/PlazCode.app" ]] || { echo 'PlazCode.app is missing. Extract the complete release ZIP.' >&2;exit 1; }
exec /usr/bin/open "$root/PlazCode.app"
