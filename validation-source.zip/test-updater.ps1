$ErrorActionPreference='Stop'
$Scriptpath=Join-Path $PSScriptRoot 'Update-PlazCode.ps1'
$tokens=$null;$errors=$null
[Management.Automation.Language.Parser]::ParseFile($Scriptpath,[ref]$tokens,[ref]$errors) | Out-Null
if($errors.Count){throw ($errors|Out-String)}
$source=Get-Content $Scriptpath -Raw
$start=$source.IndexOf('    $agentPaths =')
$end=$source.IndexOf('    foreach ($file in $files) {',$start)
$block=$source.Substring($start,$end-$start)
$install=Join-Path ([IO.Path]::GetTempPath()) ('PlazCode-test-'+[guid]::NewGuid())
New-Item $install -ItemType Directory | Out-Null
$exe=Join-Path $install 'PlazCode.exe';[IO.File]::WriteAllText($exe,'placeholder')
$global:Stoppedids=@();$global:Waitedids=@();$global:Removed=$false
$global:Lockedhandle=[IO.File]::Open($exe,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::None)
function Get-Process { param($Name,$Id,$ErrorAction) if(!$global:Removed){[pscustomobject]@{Id=101;Path=$exe};[pscustomobject]@{Id=202;Path='/different-install/PlazCode.exe'}} }
function Stop-Process { param($Id,[switch]$Force,$ErrorAction) $global:Stoppedids+= $Id }
function Wait-Process { param($Id,$Timeout,$ErrorAction) $global:Waitedids+=$Id;$global:Lockedhandle.Dispose();$global:Removed=$true }
function Set-UpdaterProgress { param($Percent,$Title,$Detail) }
$ShowProgress=$false;$stopped=$false
Invoke-Expression $block
if(!$stopped -or $global:Stoppedids.Count -ne 1 -or $global:Stoppedids[0] -ne 101 -or $global:Waitedids[0] -ne 101){throw 'Wrong process stopped or wait missing'}
# Persistent file locks must time out before entering the copy loop.
$global:Lockedhandle=[IO.File]::Open($exe,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::None)
$timeoutBlock=$block.Replace('AddSeconds(20)','AddMilliseconds(300)')
$failed=$false
try {Invoke-Expression $timeoutBlock}catch {if($_.Exception.Message -notlike '*still locked*'){throw};$failed=$true}finally{$global:Lockedhandle.Dispose()}
if(!$failed){throw 'Persistent lock did not abort'}
$copyStart=$source.IndexOf('    foreach ($file in $files) {',$start)
if($source.IndexOf('[IO.File]::Open',$start) -gt $copyStart){throw 'Lock verification occurs after copying'}
Remove-Item $install -Recurse -Force
Write-Host 'PASS: PowerShell syntax; exact installation process scope; stop/wait then lock release; persistent-lock abort before copying.'
