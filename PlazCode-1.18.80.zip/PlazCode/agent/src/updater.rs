use axum::{Json, response::IntoResponse};
use futures::StreamExt;
use serde::Serialize;
use serde_json::Value;
use std::{path::PathBuf, sync::Mutex, time::Duration};
use tokio::io::AsyncWriteExt;

const DEFAULT_FEED: &str = "https://raw.githubusercontent.com/stoveez/PlazCodeneww/main/latest.json";
#[derive(Clone, Serialize)]
pub struct Status { installed: String, latest: Option<String>, available: bool, busy: bool, progress: u8, message: String, error: Option<String> }
fn folder() -> PathBuf { std::env::current_exe().ok().and_then(|p| p.parent().map(|p| p.to_owned())).unwrap_or_default() }
fn installed() -> String {
    std::fs::read(folder().join("manifest.json")).ok().and_then(|raw| serde_json::from_slice::<Value>(&raw).ok())
        .and_then(|value| value["version"].as_str().map(str::to_owned)).unwrap_or_else(|| env!("CARGO_PKG_VERSION").into())
}
static STATUS: once_cell::sync::Lazy<Mutex<Status>> = once_cell::sync::Lazy::new(|| Mutex::new(Status { installed: installed(), latest: None, available: false, busy: false, progress: 0, message: "Check for the latest published update.".into(), error: None }));
fn state() -> std::sync::MutexGuard<'static, Status> { STATUS.lock().unwrap_or_else(|e| e.into_inner()) }
fn progress(percent: u8, message: &str) { let mut s=state();s.progress=percent;s.message=message.into(); }
fn version(text: &str) -> anyhow::Result<Vec<u32>> {
    let mut parts = text.split('.').map(str::parse::<u32>).collect::<Result<Vec<_>,_>>()?;
    anyhow::ensure!((2..=4).contains(&parts.len()), "Invalid release version."); while parts.len()<4 { parts.push(0); } Ok(parts)
}
fn validate(feed: &Value) -> anyhow::Result<(String,String,String)> {
    let ver=feed["version"].as_str().unwrap_or("");version(ver)?;
    let url=feed["url"].as_str().unwrap_or("");
    anyhow::ensure!(reqwest::Url::parse(url)?.scheme()=="https", "Release download must use HTTPS.");
    let hash=feed["sha256"].as_str().unwrap_or("");
    anyhow::ensure!(hash.len()==64 && hash.bytes().all(|b| b.is_ascii_hexdigit()), "Invalid release checksum.");
    Ok((ver.into(),url.into(),hash.into()))
}
async fn run(install: bool) -> anyhow::Result<()> {
    let root=folder();
    let source=std::fs::read(root.join("update-source.json")).ok().and_then(|raw| serde_json::from_slice::<Value>(&raw).ok());
    let url=source.as_ref().and_then(|value| value["feedUrl"].as_str()).filter(|url| !url.is_empty()).unwrap_or(DEFAULT_FEED);
    anyhow::ensure!(reqwest::Url::parse(url)?.scheme()=="https", "Update feed must use HTTPS.");
    progress(0,"Checking for updates…");
    let client=reqwest::Client::builder().timeout(Duration::from_secs(180)).build()?;
    let raw=client.get(url).timeout(Duration::from_secs(30)).send().await?.error_for_status()?.bytes().await?;
    anyhow::ensure!(raw.len()<=65536,"Release feed is too large.");
    let (latest,download,hash)=validate(&serde_json::from_slice(&raw)?)?;
    let available=version(&latest)? > version(&installed())?;
    { let mut s=state();s.installed=installed();s.latest=Some(latest.clone());s.available=available; }
    if !available { progress(100,"Already up to date.");return Ok(()); }
    if !install { progress(0,"A newer version is ready to install.");return Ok(()); }
    #[cfg(not(windows))] anyhow::bail!("Installing desktop updates requires Windows.");
    #[cfg(windows)] {
        use std::os::windows::process::CommandExt;
        let helper=root.join("Update-PlazCode.ps1");anyhow::ensure!(helper.is_file(),"Update-PlazCode.ps1 is missing.");
        let stage=std::env::temp_dir().join(format!("PlazCode-download-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH)?.as_millis()));
        std::fs::create_dir_all(&stage)?;let path=stage.join("release.zip");
        let response=client.get(download).send().await?.error_for_status()?;
        let total=response.content_length().unwrap_or(0);anyhow::ensure!(total<=64*1024*1024,"Release is too large.");
        let mut file=tokio::fs::File::create(&path).await?;let mut stream=response.bytes_stream();let mut bytes=0u64;
        while let Some(chunk)=stream.next().await { let chunk=chunk?;bytes+=chunk.len() as u64;anyhow::ensure!(bytes<=64*1024*1024,"Release exceeds 64 MB.");file.write_all(&chunk).await?;
            progress(if total>0 { ((bytes*85/total).min(85)) as u8 } else { 35 },"Downloading update…"); }
        file.flush().await?;drop(file);progress(90,"Verifying and installing. PlazCode will close and relaunch…");
        let mut helper_process = std::process::Command::new("powershell.exe").args(["-NoProfile","-ExecutionPolicy","Bypass","-File"]).arg(helper).arg("-ZipPath").arg(path).arg("-ExpectedSha256").arg(hash).arg("-ExpectedVersion").arg(latest).arg("-ShowProgress")
            .current_dir(&root).creation_flags(0x08000000).spawn()?;
        let result = tokio::task::spawn_blocking(move || helper_process.wait()).await??;
        anyhow::ensure!(result.success(), "Updater could not complete installation. Review the updater error window and retry.");
        progress(100,"Updater finished. Reload the extension and refresh AI chat tabs.");
    }
    Ok(())
}
pub async fn get() -> Json<Status> { Json(state().clone()) }
pub async fn post(Json(value): Json<Value>) -> axum::response::Response {
    let install=match value["action"].as_str() { Some("check")=>false,Some("install")=>true,_=>return (axum::http::StatusCode::BAD_REQUEST,Json(serde_json::json!({"error":"Unknown update action."}))).into_response() };
    { let mut s=state();if s.busy { return (axum::http::StatusCode::CONFLICT,Json(serde_json::json!({"error":"An update is already running."}))).into_response(); }s.busy=true;s.error=None;s.progress=0;s.message="Checking for updates…".into(); }
    tokio::spawn(async move { let result=run(install).await;let mut s=state();if let Err(error)=result { s.error=Some(error.to_string());s.message="Update failed. Your installed files were not changed by the downloader.".into(); }s.busy=false; });
    Json(serde_json::json!({"ok":true})).into_response()
}
#[cfg(test)] mod tests {
    use super::*;
    #[test] fn release_validation_and_versions() {
        assert!(version("1.18.80").unwrap()>version("1.18.79").unwrap());assert_eq!(version("1.18.80").unwrap(),version("1.18.80.0").unwrap());assert!(version("bad").is_err());
        assert!(validate(&serde_json::json!({"version":"1.18.80","url":"http://example.com/a.zip","sha256":"a".repeat(64)})).is_err());
        assert!(validate(&serde_json::json!({"version":"1.18.80","url":"https://example.com/a.zip","sha256":"bad"})).is_err());
        assert!(validate(&serde_json::json!({"version":"1.18.80","url":"https://example.com/a.zip","sha256":"a".repeat(64)})).is_ok());
    }
}
