// SPDX-License-Identifier: GPL-3.0-or-later
const PlazCodeVersion = (() => {
  function version(value) {
    if (typeof value !== 'string' || !/^\d+(?:\.\d+){1,3}$/.test(value)) return null;
    const parts = value.split('.').map(Number);
    if (!parts.every(Number.isSafeInteger)) return null;
    while (parts.length < 4) parts.push(0);
    return parts;
  }
  function describe(current, status, now = Date.now()) {
    const local = version(current), latest = version(status && status.latest);
    if (status && status.check_error) return {label:'Check unavailable',color:'#8598b1'};
    const checked = Number(status && status.checked_at);
    if (!local || !latest || !checked || now - checked > 15 * 60 * 1000 || checked > now + 60000) return {label:'Not checked',color:'#8598b1'};
    const difference = local.findIndex((part, index) => part !== latest[index]);
    const outdated = difference >= 0 && local[difference] < latest[difference];
    return {label:outdated?'Outdated':'Up to date',color:outdated?'#ff696c':'#31e0a4'};
  }
  function render(element, current, status, prefix = 'v', extra = '') {
    if (!element) return;
    const result = describe(current, status);
    element.textContent = prefix + current + ' (' + result.label + ')' + extra;
    if (element.style.setProperty) element.style.setProperty('color', result.color, 'important');
    else element.style.color = result.color;
    element.title = status && status.latest ? 'Latest published release: ' + status.latest : 'Latest published release has not been checked.';
    element.setAttribute('aria-label', element.textContent);
  }
  return {describe,render};
})();
if (typeof module !== 'undefined' && module.exports) module.exports = PlazCodeVersion;
