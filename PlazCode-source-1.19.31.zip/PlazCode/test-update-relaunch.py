"""Run the updater's real relaunch function against the compiled desktop in a temporary Windows installation."""
from pathlib import Path
import ctypes,json,os,shutil,subprocess,tempfile,time
if os.name!='nt':raise SystemExit('Windows desktop relaunch check runs on Windows only.')
source=Path('Update-PlazCode.ps1').read_text();helper=source[source.index('function Start-UpdatedPlazCode('):source.index('function Get-ExtensionRoot(')]
version=json.loads(Path('release-notes.json').read_text())[0]['version']
with tempfile.TemporaryDirectory(prefix='plazcode-relaunch-',ignore_cleanup_errors=True) as temporary:
 root=Path(temporary);install=root/'install';install.mkdir();stage=root/'stage';stage.mkdir();config=root/'config';config.mkdir()
 shutil.copy2('agent/target/release/PlazCode.exe',install/'PlazCode.exe')
 (install/'PlazCode-Extension').mkdir();(install/'PlazCode-Extension/manifest.json').write_text(json.dumps({'version':version}))
 env={**os.environ,'LOCALAPPDATA':str(config),'XDG_CONFIG_HOME':str(config),'PLAZCODE_WORKSPACE_ROOT':str(root/'workspace')}
 for background in [True,False]:
  marker=stage/'desktop-ready.json';marker.unlink(missing_ok=True)
  fixture=root/'relaunch.ps1';fixture.write_text("param([string]$install,[string]$stage,[string]$version,[bool]$BackgroundUpdate)\n$ErrorActionPreference='Stop'\nfunction Set-UpdaterProgress {param($Percent,$Title,$Detail)}\n"+helper+'\nStart-UpdatedPlazCode $version\n')
  # Use explicit switch values through a command script, avoiding native boolean argument conversion.
  launch=root/'launch.ps1';launch.write_text("& $args[0] -install $args[1] -stage $args[2] -version $args[3] -BackgroundUpdate "+('$true' if background else '$false')+'\n')
  pid=None;started=time.monotonic()
  try:
   result=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(launch),str(fixture),str(install),str(stage),version],env=env,capture_output=True,text=True,timeout=65)
   if marker.exists():pid=json.loads(marker.read_text())['pid']
   assert result.returncode==0,(result.stdout,result.stderr,(install/'logs/agent.log').read_text() if (install/'logs/agent.log').exists() else '')
   ready=json.loads(marker.read_text());assert ready['version']==version and ready['desktop_ready'] and pid
   user32=ctypes.windll.user32;windows=[];callback=ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p)
   def inspect(hwnd,_):
    owner=ctypes.c_ulong();user32.GetWindowThreadProcessId(ctypes.c_void_p(hwnd),ctypes.byref(owner))
    if owner.value==pid and user32.IsWindowVisible(ctypes.c_void_p(hwnd)):windows.append(hwnd)
    return True
   user32.EnumWindows(callback(inspect),0);assert windows,'Restarted desktop has no accessible window'
   if background:
    assert any(user32.IsIconic(ctypes.c_void_p(hwnd)) for hwnd in windows),'Background restart must remain in the taskbar minimized'
    user32.GetForegroundWindow.restype=ctypes.c_void_p
    assert user32.GetForegroundWindow() not in windows,'Background restart stole focus'
   print('PASS real updater relaunch:', 'background minimized/no focus' if background else 'foreground visible', 'desktop-ready version/pid confirmed in',round(time.monotonic()-started,2),'seconds',flush=True)
  finally:
   if pid:subprocess.run(['taskkill','/F','/T','/PID',str(pid)],capture_output=True)
   else:
    subprocess.run(['powershell.exe','-NoProfile','-Command',"Get-Process PlazCode -ErrorAction SilentlyContinue | Where-Object {$_.Path -eq $args[0]} | Stop-Process -Force",str(install/'PlazCode.exe')],capture_output=True)

   # A terminated WebView process may release its profile locks asynchronously.
   for retry in range(30):
    try:
     if (install/'PlazCode.exe.WebView2').exists():shutil.rmtree(install/'PlazCode.exe.WebView2')
     break
    except PermissionError:time.sleep(.2)
