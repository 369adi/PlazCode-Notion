use std::path::{Path,PathBuf};
pub fn installation_root_at(executable:&Path)->PathBuf {
    for ancestor in executable.ancestors().skip(1) {
        if ancestor.extension().is_some_and(|extension|extension=="app") {
            return ancestor.parent().unwrap_or_else(||Path::new(".")).to_owned();
        }
    }
    executable.parent().unwrap_or_else(||Path::new(".")).to_owned()
}
pub fn installation_root()->PathBuf {std::env::current_exe().ok().map(|path|installation_root_at(&path)).unwrap_or_default()}
#[cfg(target_os="macos")]
pub fn configuration_root()->PathBuf {PathBuf::from(std::env::var_os("HOME").unwrap_or_default()).join("Library/Application Support/PlazCode")}
#[cfg(test)]mod tests{use super::*;#[test]fn bundle_root_is_outside_signed_app(){assert_eq!(installation_root_at(Path::new("/Applications/PlazCode/PlazCode.app/Contents/MacOS/PlazCode")),Path::new("/Applications/PlazCode"));assert_eq!(installation_root_at(Path::new("/opt/PlazCode/PlazCode")),Path::new("/opt/PlazCode"));}}

#[cfg(target_os="macos")]
pub fn prepare_application_path() {
    // Finder does not inherit a user's interactive shell PATH.
    let mut paths=vec![PathBuf::from("/opt/homebrew/bin"),PathBuf::from("/usr/local/bin")];
    if let Some(home)=std::env::var_os("HOME") { paths.push(PathBuf::from(home).join(".local/bin")); }
    if let Some(existing)=std::env::var_os("PATH") { paths.extend(std::env::split_paths(&existing)); }
    if let Ok(path)=std::env::join_paths(paths) { std::env::set_var("PATH",path); }
}

// The helper waits for this marker after the WebView reports its UI loaded.
pub fn write_update_ready(path: &Path) -> std::io::Result<()> {
    let temporary = path.with_extension("pending");
    let payload = serde_json::json!({"version":env!("CARGO_PKG_VERSION"),"pid":std::process::id(),"desktop_ready":true});
    std::fs::write(&temporary, payload.to_string())?;
    std::fs::rename(temporary, path)
}
#[cfg(test)] mod update_ready_tests {
    #[test] fn ready_marker_identifies_the_running_build_and_is_atomic() {
        let root=std::env::temp_dir().join(format!("plazcode-ready-{}",std::process::id()));std::fs::create_dir_all(&root).unwrap();
        let path=root.join("ready.json");super::write_update_ready(&path).unwrap();
        let value:serde_json::Value=serde_json::from_slice(&std::fs::read(&path).unwrap()).unwrap();
        assert_eq!(value["version"],env!("CARGO_PKG_VERSION"));assert_eq!(value["pid"],std::process::id());assert_eq!(value["desktop_ready"],true);assert!(!path.with_extension("pending").exists());std::fs::remove_dir_all(root).unwrap();
    }
}
