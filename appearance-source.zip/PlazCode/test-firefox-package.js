const assert=require('assert'),fs=require('fs'),os=require('os'),path=require('path'),cp=require('child_process'),vm=require('vm');
const root=__dirname,tmp=fs.mkdtempSync(path.join(os.tmpdir(),'plazcode-firefox-package-'));
try {
  cp.execFileSync(process.env.PYTHON || (process.platform==='win32'?'python':'python3'),[path.join(root,'release-tools/build-firefox.py'),path.join(root,'PlazCode-Extension'),path.join(tmp,'extension'),path.join(tmp,'firefox.zip')]);
  const chrome=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'))),firefox=JSON.parse(fs.readFileSync(path.join(tmp,'extension/manifest.json')));
  assert.deepStrictEqual(firefox.background,{scripts:['background.js']});assert(!firefox.minimum_chrome_version);assert.equal(firefox.browser_specific_settings.gecko.id,'plazcode@plazcode.local');assert.equal(firefox.browser_specific_settings.gecko.strict_min_version,'140.0');
  assert.deepStrictEqual(firefox.content_scripts,chrome.content_scripts);assert.deepStrictEqual(firefox.permissions,chrome.permissions);assert.deepStrictEqual(firefox.host_permissions,chrome.host_permissions);
  for(const s of firefox.content_scripts)for(const f of [...(s.js||[]),...(s.css||[])])assert(fs.existsSync(path.join(tmp,'extension',f)),f);
  assert.equal(firefox.content_scripts.filter(s=>s.world==='MAIN').length,3);
  for(const f of ['LICENSE','SOURCE.txt','BRANDING-NOTICE.txt'])assert(fs.readFileSync(path.join(tmp,'extension',f)).equals(fs.readFileSync(path.join(root,f))),f);
  for(const f of ['background.js','core/main.js','core/clarification.js','providers/notion.js','popup.js'])assert(fs.readFileSync(path.join(tmp,'extension',f)).equals(fs.readFileSync(path.join(root,'PlazCode-Extension',f))),f);
  const source=fs.readFileSync(path.join(root,'background.js'),'utf8'),start=source.indexOf('function pairingIdentity()'),end=source.indexOf('async function bridgeFetch',start),code=source.slice(start,end);
  for(const [url,id,expected] of [['chrome-extension://abcdefghijklmnopabcdefghijklmnop/','abcdefghijklmnopabcdefghijklmnop','abcdefghijklmnopabcdefghijklmnop'],['moz-extension://12345678-1234-1234-1234-123456789abc/','plazcode@plazcode.local','12345678-1234-1234-1234-123456789abc']])assert.equal(vm.runInNewContext(code+';pairingIdentity()', {URL,chrome:{runtime:{id,getURL:()=>url}}}),expected);
  assert(/"X-PlazCode-Extension"\s*:\s*pairingIdentity\(\)/.test(source));
  console.log('Firefox manifest, full provider coverage/MAIN taps, shared script parity, install guidance and UUID pairing identity passed.');
} finally {fs.rmSync(tmp,{recursive:true,force:true});}
