#!/bin/bash
set -euo pipefail
root=$(cd -- "$(dirname -- "$0")" && pwd)
source="$root/update-source.json"
shared='https://raw.githubusercontent.com/stoveez/PlazCode/main/latest.json'
mac='https://raw.githubusercontent.com/stoveez/PlazCode/main/latest-macos.json'
if [[ -e "$source" ]];then
 current=$(/usr/bin/plutil -extract feedUrl raw -o - "$source") || { echo 'Existing update source could not be read; it was preserved.' >&2;exit 0; }
 [[ -z "$current" || "$current" == "$shared" ]] || exit 0
 temp=$(/usr/bin/mktemp "$root/.mac-update-source.XXXXXX")
 trap '/bin/rm -f "$temp"' EXIT
 /bin/cp "$source" "$temp"
 /usr/bin/plutil -replace feedUrl -string "$mac" "$temp"
 /bin/mv "$temp" "$source"
 trap - EXIT
else
 temp=$(/usr/bin/mktemp "$root/.mac-update-source.XXXXXX")
 trap '/bin/rm -f "$temp"' EXIT
 printf '{"feedUrl":"%s"}\n' "$mac" > "$temp"
 /bin/mv "$temp" "$source"
 trap - EXIT
fi
