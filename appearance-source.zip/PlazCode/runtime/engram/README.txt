Engram 3.0.0
Official source: https://github.com/Gentleman-Programming/engram
MIT license. Copyright (c) 2026 Alan Buscaglia.
Official release binaries are verified with pinned SHA256 hashes before packaging.
Local project databases use the existing PlazCode configuration directory. Cloud autosync is disabled.
