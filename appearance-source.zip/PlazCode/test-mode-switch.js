const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const bg=fs.readFileSync('background.js','utf8'),main=fs.readFileSync('core/main.js','utf8');
const listener=bg.slice(bg.indexOf('chrome.storage?.onChanged.addListener((changes, area) => {',bg.indexOf('function engineLabel()')),bg.indexOf('// Chat sites where'));
const handler=bg.slice(bg.indexOf('      case "rs-set-engine":'),bg.indexOf('      case "rs-set-full":'));
async function sequence(storageFirst){
 let change,closes=0,connects=0,broadcasts=0,failures=0,responses=0;
 const box={engine:'roblox',normalizeEngine:v=>v==='local'?'local':'roblox',ENGINE_KEY:'rs-engine',ws:{close(){closes++;}},connected:true,mcpAlive:true,toolsCache:[1],serversCache:[1],studioConnected:true,studioApp:true,studioProc:true,robloxEditorConnected:true,RECONNECT_MIN:500,reconnectDelay:500,log(){},engineLabel(){},engineUrl(){},failAllPending(){failures++;},connect(){connects++;box.ws={close(){closes++;}};},broadcastStatus(){broadcasts++;},sendResponse(){responses++;},msg:{engine:'local'},chrome:{storage:{onChanged:{addListener(fn){change=fn;}},local:{async set(){change({'rs-engine':{newValue:'local'}},'local');}}},tabs:{async query(){return []},sendMessage(){return Promise.resolve()}}},PROVIDER_URLS:[]};
 vm.createContext(box);vm.runInContext(listener,box);
 if(storageFirst)change({'rs-engine':{newValue:'local'}},'local');
 await vm.runInContext('(async()=>{switch("rs-set-engine"){'+handler+'}})()',box);
 assert.equal(box.engine,'local');assert.equal(closes,1);assert.equal(connects,1);assert.equal(broadcasts,1);assert.equal(failures,1);assert.equal(responses,1);
 await vm.runInContext('(async()=>{switch("rs-set-engine"){'+handler+'}})()',box);
 assert.equal(connects,1,'An identical engine message must not tear down the live connection');
}
(async()=>{await sequence(true);await sequence(false);
 const guard=main.slice(main.indexOf('      if (!s) return;',main.indexOf('    function setStatus(s)')),main.indexOf('      A.bridge = s;',main.indexOf('    function setStatus(s)')));
 for(const [engine,connected,expected] of [['roblox',true,undefined],['local',false,undefined],['local',true,true]]){
 const b={s:{engine,connected},currentEngine:'local',engineSwitchUntil:200,Date:{now:()=>100}};vm.createContext(b);assert.equal(vm.runInContext('(function(){'+guard+'return true;})()',b),expected);
 }
 const dblStart=main.indexOf('engineEl.addEventListener("dblclick"');const block=main.slice(dblStart,main.indexOf('          engineToast(next);',dblStart)+'          engineToast(next);'.length)+'\n});';
 let eventHandler,switches=0;const b={engineEl:{addEventListener(_,fn){eventHandler=fn}},currentMode:'local',Date,lastManualEngineAt:0,chrome:{storage:{local:{set(){}}},runtime:{sendMessage(){return Promise.resolve()}}},setEngine(){switches++;},engineToast(){}};vm.createContext(b);vm.runInContext(block,b);eventHandler({stopPropagation(){},target:{closest:()=>({})}});assert.equal(switches,0,'Double-clicking a segment must not cycle back');
 console.log('Both storage/message orderings switch once; duplicate requests retain the connection; transitional status and segment double-clicks do not reverse the selected mode.');
})().catch(e=>{console.error(e);process.exitCode=1;});
