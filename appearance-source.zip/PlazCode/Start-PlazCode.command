#!/bin/bash
set -euo pipefail
root=$(cd -- "$(dirname -- "$0")" && pwd)
[[ -d "$root/PlazCode.app" ]] || { echo 'PlazCode.app is missing. Extract the complete release ZIP.' >&2;exit 1; }
/bin/bash "$root/Configure-MacOS-Updates.command"
exec /usr/bin/open "$root/PlazCode.app"
