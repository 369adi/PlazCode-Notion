const PlazCodeClarification = (() => {
  const INSTRUCTION = '\nBEFORE ACTING: Assess the request, existing project and constraints first. For a clear task, proceed with targeted work. If materially unclear choices would change the scope, call plazcode_clarify BEFORE changing anything. Provide 2–3 distinct options with labels and scope, recommend one with a reason, and ask 1–3 necessary questions. This opens a user panel and waits for their answer. Do not pick an option yourself, send reminders, repeat the question, or run other actions while waiting. Continue only from the returned answer. Do not ask for hidden reasoning; give concise practical scope and tradeoffs.\n';
  const DESCRIPTION = 'plazcode_clarify {question:string, options:[{id:string,label:string,scope:string}] (2–3), recommended_id:string, recommendation:string, questions:[string] (1–3)} — clarify materially unclear work before acting; waits indefinitely without reminders for an explicit answer.';
  function validate(value) {
    const string = (text, max) => typeof text === 'string' && !!text.trim() && text.length <= max;
    if (!value || !string(value.question, 1200) || !Array.isArray(value.options) || value.options.length < 2 || value.options.length > 3) throw Error('Provide a question and 2–3 options.');
    if (value.options.some(option => !option || !string(option.id, 60) || !string(option.label, 120) || !string(option.scope, 1800))) throw Error('Each option needs an id, label and scope.');
    if (new Set(value.options.map(option => option.id)).size !== value.options.length) throw Error('Option ids must be distinct.');
    if (!value.options.some(option => option.id === value.recommended_id) || !string(value.recommendation, 1200)) throw Error('Recommend one option and explain why.');
    if (!Array.isArray(value.questions) || value.questions.length < 1 || value.questions.length > 3 || value.questions.some(question => !string(question, 500))) throw Error('Ask 1–3 necessary clarifying questions.');
    return value;
  }
  function create({ document, context, provider, mount, cancelled = () => false, onCancel = () => {}, changed = () => {} }) {
    let pending = null;
    function finish(answer, error) {
      if (!pending) return;
      const current = pending; pending = null;
      clearInterval(current.timer); current.host.remove();
      if (current.focus && current.focus.isConnected) try { current.focus.focus(); } catch {}
      changed(false);
      if (error) current.reject(error); else current.resolve(answer);
    }
    function cancel(reason = 'Clarification cancelled. No option was selected.') {
      const error = new Error(reason); error.name = 'AbortError'; finish(null, error);
    }
    function request(args) {
      validate(args);
      if (pending) throw Error('A clarification is already waiting for an answer.');
      const key = context(), host = document.createElement('div');host.id = 'rs-clarification-host';
      const shadow = host.attachShadow({ mode: 'closed' });
      const style = document.createElement('style');
      style.textContent = ':host{position:fixed;inset:0;z-index:2147483646;color:var(--rs-text,#edf2fa);font:14px/1.5 system-ui,sans-serif}*{box-sizing:border-box}.shade{position:absolute;inset:0;background:#0009;display:grid;place-items:center;padding:20px}.panel{width:min(660px,100%);max-height:calc(100dvh - 40px);overflow:auto;background:var(--pc-bg,var(--rs-bg,#111a26));border:1px solid var(--pc-accent,var(--rs-accent,#ffa83d));border-radius:20px;padding:24px;box-shadow:0 20px 70px #0008;animation:appear .18s ease-out}h2{margin:0 0 8px;font-size:21px;outline:none}p{margin:0 0 16px;overflow-wrap:anywhere}.muted{color:var(--rs-muted,#aab6c6)}.options,.questions{display:grid;gap:12px;margin:18px 0}label{display:grid;gap:7px}.option{grid-template-columns:20px 1fr;border:1px solid #8090a044;border-radius:12px;padding:14px;cursor:pointer;background:#ffffff05}.option:has(input:checked){border-color:var(--pc-accent,var(--rs-accent,#ffa83d));background:#ffa83d14}input[type=radio]{accent-color:var(--pc-accent,var(--rs-accent,#ffa83d));margin:5px 0}strong{display:block}small{display:block;white-space:pre-wrap;overflow-wrap:anywhere}.badge{color:var(--pc-accent,var(--rs-accent,#ffa83d));font-size:12px}textarea{width:100%;min-height:74px;resize:vertical;color:inherit;background:#0003;border:1px solid #8090a066;border-radius:10px;padding:11px;font:inherit}textarea:focus-visible,button:focus-visible,input:focus-visible{outline:2px solid var(--pc-accent,var(--rs-accent,#ffa83d));outline-offset:3px}.actions{display:flex;gap:12px;justify-content:flex-end;flex-wrap:wrap;margin-top:20px;position:sticky;bottom:0;padding:14px 0 0;background:var(--pc-bg,var(--rs-bg,#111a26));border-top:1px solid #8090a044}button{border:1px solid #8090a066;border-radius:10px;padding:10px 16px;font:inherit;color:inherit;background:#ffffff08;cursor:pointer}button[type=submit]{background:var(--pc-accent,var(--rs-accent,#ffa83d));color:#111822;font-weight:650}button:disabled{opacity:.45;cursor:default}@keyframes appear{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}@media(prefers-reduced-motion:reduce){.panel{animation:none}}@media(max-width:420px){.shade{padding:12px}.panel{padding:18px;max-height:calc(100dvh - 24px)}.actions button{flex:1}}';
      shadow.append(style);
      const shade = document.createElement('div');shade.className = 'shade';shadow.append(shade);
      const form = document.createElement('form');form.className = 'panel';form.setAttribute('role','dialog');form.setAttribute('aria-modal','true');form.setAttribute('aria-label', provider() + ' is asking you…');shade.append(form);
      const add = (tag, text, parent = form, className = '') => {const node = document.createElement(tag);node.textContent = text;node.className = className;parent.append(node);return node;};
      const heading = add('h2', provider() + ' is asking you…');heading.tabIndex = -1;
      add('p',args.question);add('p','Waiting for a response. Nothing will run until an answer is submitted.',form,'muted');
      const options = add('div','',form,'options');
      for (const option of args.options) {
        const label = add('label','',options,'option'),radio = document.createElement('input');radio.type='radio';radio.name='choice';radio.value=option.id;label.append(radio);
        const body = add('span','',label);add('strong',option.label,body);
        if (option.id === args.recommended_id) add('span','Recommended',body,'badge');
        add('small',option.scope,body);
      }
      add('p','Recommendation: '+args.recommendation);
      const questions = add('div','',form,'questions');
      const answers = args.questions.map(question => {const label=add('label','',questions);add('span',question,label);const input=document.createElement('textarea');input.maxLength=6000;input.required=true;label.append(input);return input;});
      const extraLabel=add('label','');add('span','Additional details or a different approach (optional)',extraLabel);
      const extra=document.createElement('textarea');extra.maxLength=10000;extraLabel.append(extra);
      const actions=add('div','',form,'actions'),stop=add('button','Cancel task',actions),submit=add('button','Submit answer',actions);stop.type='button';submit.type='submit';submit.disabled=true;
      const valid=()=>!!(form.querySelector('input:checked') || extra.value.trim()) && answers.every(input=>input.value.trim());
      form.addEventListener('input',()=>{submit.disabled=!valid();});form.addEventListener('change',()=>{submit.disabled=!valid();});
      stop.addEventListener('click',()=>{cancel();onCancel();});
      form.addEventListener('submit',event=>{event.preventDefault();if(!valid() || context()!==key){if(context()!==key)cancel('Chat or engine changed. Clarification cancelled.');return;}
        const selected=form.querySelector('input:checked');
        finish({selected_option:selected ? args.options.find(option=>option.id===selected.value) : null,answers:args.questions.map((question,index)=>({question,answer:answers[index].value})),additional_details:extra.value});
      });
      form.addEventListener('keydown',event=>{if(event.key!=='Tab')return;const controls=[heading,...form.querySelectorAll('input,textarea,button')].filter(node=>!node.disabled);const current=shadow.activeElement;if(event.shiftKey&&current===controls[0]){event.preventDefault();controls.at(-1).focus();}else if(!event.shiftKey&&current===controls.at(-1)){event.preventDefault();controls[0].focus();}});
      return new Promise((resolve,reject)=>{
        pending={resolve,reject,host,focus:document.activeElement,timer:setInterval(()=>{if(context()!==key || cancelled())cancel('Task stopped or chat/engine changed. Clarification cancelled.');},500)};
        (mount() || document.body).append(host);changed(true);heading.focus();
      });
    }
    return {request,cancel,isWaiting:()=>!!pending};
  }
  return {create,validate,INSTRUCTION,DESCRIPTION};
})();
if (typeof module !== 'undefined' && module.exports) module.exports = PlazCodeClarification;
