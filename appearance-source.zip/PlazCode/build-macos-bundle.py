from pathlib import Path
import zipfile,stat,shutil,plistlib,subprocess,urllib.request,hashlib,tarfile,io
base=Path('../../../PlazCode-1.19.18.zip')
output=Path('target/release/PlazCode.app')
with zipfile.ZipFile(base) as z:
 for info in z.infolist():
  prefix='PlazCode/PlazCode.app/'
  if not info.filename.startswith(prefix):continue
  relative=info.filename[len(prefix):]
  if not relative or '_CodeSignature' in relative:continue
  path=output/relative
  if info.is_dir():path.mkdir(parents=True,exist_ok=True);continue
  path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(z.read(info));path.chmod((info.external_attr>>16)&0o777 or 0o644)
shutil.copy2('target/release/PlazCode',output/'Contents/MacOS/PlazCode')
(output/'Contents/MacOS/PlazCode').chmod(0o755)
p=output/'Contents/Info.plist';data=plistlib.loads(p.read_bytes());data['CFBundleShortVersionString']=data['CFBundleVersion']='1.19.19';p.write_bytes(plistlib.dumps(data))
engram=output/'Contents/Resources/engram';engram.mkdir(parents=True,exist_ok=True)
for arch,expected in [('amd64','68cc3eebbb265d1c45999a429d1e6774150ba71ac008f4dd381b9d73b10c79dd'),('arm64','54e080ed64a1d1b7b8a5d59e5a6d17100adbd69a6aafbb73d270dbeb37c03266')]:
 with urllib.request.urlopen('https://github.com/Gentleman-Programming/engram/releases/download/v3.0.0/engram_3.0.0_darwin_'+arch+'.tar.gz',timeout=60) as response:raw=response.read(12*1024*1024)
 assert hashlib.sha256(raw).hexdigest()==expected,'Official Engram checksum mismatch'
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:data=archive.extractfile(next(n for n in archive.getmembers() if Path(n.name).name=='engram')).read()
 path=engram/('engram-darwin-'+arch);path.write_bytes(data);path.chmod(0o755)
 subprocess.run(['codesign','--force','--sign','-',str(path)],check=True)
shutil.copy2('../runtime/engram/LICENSE',engram/'LICENSE')
subprocess.run(['codesign','--force','--deep','--sign','-',str(output)],check=True)
subprocess.run(['codesign','--verify','--deep','--strict',str(output)],check=True)
with zipfile.ZipFile('target/release/PlazCode-app.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in output.rglob('*'):
  if p.is_file():z.write(p,p.relative_to(output.parent))
print('Universal macOS app bundle signed and verified.')
