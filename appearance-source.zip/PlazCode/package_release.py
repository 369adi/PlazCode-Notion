"""Stage a clean split install and an old-installer-compatible update archive.
Run from the combined source folder after building PlazCode.exe. No user data
is included. Published ZIPs are immutable: this command refuses to overwrite.
"""
from pathlib import Path
import hashlib, json, re, zipfile

ROOT = Path(__file__).resolve().parent
EXTENSION_FILES = {'manifest.json', 'background.js', 'popup.html', 'popup.js',
                   'overlay.css', 'icon.png', 'ollama.html', 'ollama-page.js'}
EXTENSION_FOLDERS = {'core', 'providers', 'ui'}
EXCLUDED = {'logs', 'target', '.git', '__pycache__', 'node_modules', 'backups',
            'runtimes', 'PlazCode.exe.WebView2'}
PRIVATE = {'config.local.json', 'plazcode-settings.json', 'bridge-pairing.json',
           'memory.json', 'chat-history.json', 'checkpoints.json', 'catalog.json', 'creations.json'}

def is_extension(relative):
    return relative.as_posix() in EXTENSION_FILES or relative.parts[0] in EXTENSION_FOLDERS

def validate(archive, version, compatibility):
    names = set(archive.namelist())
    prefix = 'PlazCode/PlazCode-Extension/'
    manifest = json.loads(archive.read(prefix + 'manifest.json'))
    assert tuple(map(int, manifest['version'].split('.'))) == tuple(map(int, version.split('.')))
    assert manifest.get('version_name', manifest['version']) == version
    assert 'PlazCode/PlazCode.exe' in names
    import plistlib, struct
    app = 'PlazCode/PlazCode.app/Contents/'
    info = plistlib.loads(archive.read(app + 'Info.plist'))
    assert tuple(map(int, info['CFBundleShortVersionString'].split('.'))) <= tuple(map(int, version.split('.')))
    binary = archive.read(app + 'MacOS/PlazCode')
    assert binary[:4] == bytes.fromhex('cafebabe'), 'Expected a universal Mac application.'
    count = struct.unpack('>I', binary[4:8])[0]
    architectures = {struct.unpack('>I', binary[8 + i * 20:12 + i * 20])[0] for i in range(count)}
    assert {0x01000007, 0x0100000c}.issubset(architectures)
    for name in ['MacOS_Setup.command', 'Start-PlazCode.command', 'Update-PlazCode.command', 'PlazCode.app/Contents/MacOS/PlazCode']:
        assert archive.getinfo('PlazCode/' + name).external_attr >> 16 & 0o111, name
    assert ('PlazCode/manifest.json' in names) == compatibility
    assets = [manifest['background']['service_worker'], manifest['action']['default_popup']]
    assets += list(manifest['icons'].values())
    for group in manifest['content_scripts']:
        assets += group.get('js', []) + group.get('css', [])
    for asset in assets:
        assert prefix + asset in names, asset
    for page in ['popup.html', 'ollama.html']:
        for asset in re.findall(r'(?:src|href)="([^"#]+)"', archive.read(prefix + page).decode()):
            if not re.match(r'(?:https?:|data:)', asset):
                # Existing Ollama page references an absent provider in 1.18.94.
                # It is outside this layout change; never exempt another missing asset.
                if (page, asset) != ('ollama.html', 'providers/ollama.js'):
                    assert prefix + asset in names, (page, asset)
    assert archive.testzip() is None
    assert not any(any(part in EXCLUDED or part in PRIVATE for part in Path(name).parts) for name in names)
    assert not any(name.endswith('.old.exe') for name in names)

def main():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    version = manifest.get('version_name', manifest['version'])
    outputs = [(ROOT.parent.parent / ('PlazCode-' + version + '.zip'), True)]
    assert all(not path.exists() for path, _ in outputs), 'Never overwrite published ZIPs.'
    files = [p for p in sorted(ROOT.rglob('*')) if p.is_file()
             and not any(part in EXCLUDED for part in p.relative_to(ROOT).parts)
             and p.name not in PRIVATE and not p.name.endswith('.old.exe')]
    metadata = []
    for output, compatibility in outputs:
        staged = output.with_suffix('.zip.tmp')
        with zipfile.ZipFile(staged, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for file in files:
                relative = file.relative_to(ROOT)
                path = relative.as_posix()
                if is_extension(relative):
                    archive.write(file, 'PlazCode/PlazCode-Extension/' + path)
                    if compatibility:
                        archive.write(file, 'PlazCode/' + path)
                else:
                    archive.write(file, 'PlazCode/' + path)
        with zipfile.ZipFile(staged) as archive:
            validate(archive, version, compatibility)
        raw = staged.read_bytes()
        staged.rename(output)
        metadata.append({'path': output.name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                         'blobsha': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()})
    print(json.dumps(metadata, indent=2))

if __name__ == '__main__':
    main()
