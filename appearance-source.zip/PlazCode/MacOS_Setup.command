#!/bin/bash
set -euo pipefail
root=$(cd -- "$(dirname -- "$0")" && pwd)
[[ -f "$root/PlazCode.app/Contents/MacOS/PlazCode" ]] || { echo 'PlazCode.app is missing. Extract the complete release ZIP.' >&2;exit 1; }
/bin/chmod 755 "$root/PlazCode.app/Contents/MacOS/PlazCode" "$root/Start-PlazCode.command" "$root/Update-PlazCode.command"
echo 'Load PlazCode-Extension in Chrome or Edge using Load unpacked. Enable Studio as MCP server in Roblox Studio Assistant settings.'
/bin/bash "$root/Configure-MacOS-Updates.command"
exec /usr/bin/open "$root/PlazCode.app"
