from pathlib import Path
import zipfile,stat,shutil,plistlib,subprocess
base=Path('../../../PlazCode-1.19.17.zip')
output=Path('target/release/PlazCode.app')
with zipfile.ZipFile(base) as z:
 for info in z.infolist():
  prefix='PlazCode/PlazCode.app/'
  if not info.filename.startswith(prefix):continue
  relative=info.filename[len(prefix):]
  if not relative or '_CodeSignature' in relative:continue
  path=output/relative
  if info.is_dir():path.mkdir(parents=True,exist_ok=True);continue
  path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(z.read(info));path.chmod((info.external_attr>>16)&0o777 or 0o644)
shutil.copy2('target/release/PlazCode',output/'Contents/MacOS/PlazCode')
(output/'Contents/MacOS/PlazCode').chmod(0o755)
p=output/'Contents/Info.plist';data=plistlib.loads(p.read_bytes());data['CFBundleShortVersionString']=data['CFBundleVersion']='1.19.18';p.write_bytes(plistlib.dumps(data))
subprocess.run(['codesign','--force','--deep','--sign','-',str(output)],check=True)
subprocess.run(['codesign','--verify','--deep','--strict',str(output)],check=True)
with zipfile.ZipFile('target/release/PlazCode-app.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in output.rglob('*'):
  if p.is_file():z.write(p,p.relative_to(output.parent))
print('Universal macOS app bundle signed and verified.')
