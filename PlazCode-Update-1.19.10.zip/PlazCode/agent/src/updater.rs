use axum::{Json, response::IntoResponse};
use futures::StreamExt;
use serde::{Serialize, Deserialize};
use serde_json::Value;
use std::{path::PathBuf, sync::Mutex, time::Duration};
use tokio::io::AsyncWriteExt;

const DEFAULT_FEED: &str = "https://raw.githubusercontent.com/stoveez/PlazCodeneww/main/latest.json";
#[derive(Clone, Serialize, Deserialize)]
pub struct ReleaseNotes { pub version: String, pub title: String, pub summary: String, #[serde(default)] pub added: Vec<String>, #[serde(default)] pub improved: Vec<String>, #[serde(default)] pub fixed: Vec<String> }
#[derive(Clone, Serialize)]
pub struct Status { installed: String, latest: Option<String>, available: bool, busy: bool, progress: u8, message: String, error: Option<String>, checked_at: u64, check_error: Option<String>, background: bool, release_notes: Vec<ReleaseNotes> }
fn folder() -> PathBuf { std::env::current_exe().ok().and_then(|p| p.parent().map(|p| p.to_owned())).unwrap_or_default() }
fn installed_at(root: &std::path::Path) -> String {
    ["PlazCode-Extension/manifest.json", "manifest.json"].iter().find_map(|path| {
        std::fs::read(root.join(path)).ok().and_then(|raw| serde_json::from_slice::<Value>(&raw).ok())
            .and_then(|value| value["version"].as_str().map(str::to_owned))
    }).unwrap_or_else(|| env!("CARGO_PKG_VERSION").into())
}
fn installed() -> String { installed_at(&folder()) }
static STATUS: once_cell::sync::Lazy<Mutex<Status>> = once_cell::sync::Lazy::new(|| Mutex::new(Status { installed: installed(), latest: None, available: false, busy: false, progress: 0, message: "Check for the latest published update.".into(), error: None, checked_at: 0, check_error: None, background: false, release_notes: serde_json::from_str(include_str!("../../release-notes.json")).unwrap_or_default() }));
static MANUAL_WAITERS: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
struct ManualWaiter;
impl Drop for ManualWaiter { fn drop(&mut self) { MANUAL_WAITERS.fetch_sub(1,std::sync::atomic::Ordering::SeqCst); } }
fn state() -> std::sync::MutexGuard<'static, Status> { STATUS.lock().unwrap_or_else(|e| e.into_inner()) }
fn progress(percent: u8, message: &str) { let mut s=state();if s.background && message=="Checking for updates…" { return; }s.progress=percent;s.message=message.into(); }
fn version(text: &str) -> anyhow::Result<Vec<u32>> {
    let mut parts = text.split('.').map(str::parse::<u32>).collect::<Result<Vec<_>,_>>()?;
    anyhow::ensure!((2..=4).contains(&parts.len()), "Invalid release version."); while parts.len()<4 { parts.push(0); } Ok(parts)
}
fn validate(feed: &Value) -> anyhow::Result<(String,String,String)> {
    let ver=feed["version"].as_str().unwrap_or("");version(ver)?;
    let url=feed["url"].as_str().unwrap_or("");
    anyhow::ensure!(reqwest::Url::parse(url)?.scheme()=="https", "Release download must use HTTPS.");
    let hash=feed["sha256"].as_str().unwrap_or("");
    anyhow::ensure!(hash.len()==64 && hash.bytes().all(|b| b.is_ascii_hexdigit()), "Invalid release checksum.");
    Ok((ver.into(),url.into(),hash.into()))
}
// Keep the connection pool alive across checks instead of repeating DNS/TLS setup.
static HTTP_CLIENT: once_cell::sync::Lazy<Result<reqwest::Client, reqwest::Error>> = once_cell::sync::Lazy::new(||
    reqwest::Client::builder().timeout(Duration::from_secs(180)).pool_idle_timeout(Duration::from_secs(90)).build());
fn feed_timeout(background: bool) -> Duration { Duration::from_secs(if background { 8 } else { 30 }) }
async fn fetch_feed(client: &reqwest::Client, url: reqwest::Url, timeout: Duration) -> anyhow::Result<Vec<u8>> {
    Ok(client.get(url).header(reqwest::header::CACHE_CONTROL,"no-cache, max-age=0")
        .timeout(timeout).send().await?.error_for_status()?.bytes().await?.to_vec())
}
const DEFAULT_REFS: &str = "https://github.com/stoveez/PlazCodeneww.git/info/refs?service=git-upload-pack";
static PINNED_FEED: once_cell::sync::Lazy<Mutex<Option<(String, Vec<u8>)>>> = once_cell::sync::Lazy::new(|| Mutex::new(None));
fn advertised_main(raw: &[u8]) -> anyhow::Result<String> {
    anyhow::ensure!(raw.len() <= 131072, "Release reference response is too large.");
    let mut at = 0;
    while at < raw.len() {
        anyhow::ensure!(at + 4 <= raw.len(), "Truncated release reference packet.");
        let size = usize::from_str_radix(std::str::from_utf8(&raw[at..at+4])?, 16)?;
        at += 4;
        if size == 0 { continue; }
        anyhow::ensure!(size >= 4 && at + size - 4 <= raw.len(), "Invalid release reference packet.");
        let packet = std::str::from_utf8(&raw[at..at+size-4])?;at += size - 4;
        let record = packet.split('\0').next().unwrap_or("").trim_end();
        if let Some((sha, name)) = record.split_once(' ') {
            if name == "refs/heads/main" {
                anyhow::ensure!(sha.len() == 40 && sha.bytes().all(|byte| byte.is_ascii_hexdigit()), "Invalid release commit.");
                return Ok(sha.to_owned());
            }
        }
    }
    anyhow::bail!("Published release branch is missing.")
}
async fn revision_feed(client: &reqwest::Client, refs: reqwest::Url, raw_base: &str, limit: Duration) -> anyhow::Result<Vec<u8>> {
    let bytes = fetch_feed(client, refs, limit.min(Duration::from_secs(5))).await?;
    let sha = advertised_main(&bytes)?;
    {
        let cached = PINNED_FEED.lock().unwrap_or_else(|error| error.into_inner());
        if let Some((previous, raw)) = cached.as_ref() { if previous == &sha { return Ok(raw.clone()); } }
    }
    let raw = fetch_feed(client, reqwest::Url::parse(&format!("{raw_base}/{sha}/latest.json"))?, limit).await?;
    anyhow::ensure!(raw.len() <= 65536, "Release feed is too large.");
    let feed: Value = serde_json::from_slice(&raw)?;validate(&feed)?;
    *PINNED_FEED.lock().unwrap_or_else(|error| error.into_inner()) = Some((sha, raw.clone()));
    Ok(raw)
}
async fn current_feed(client: &reqwest::Client, url: &str, limit: Duration) -> anyhow::Result<Vec<u8>> {
    tokio::time::timeout(limit, async {
        if url == DEFAULT_FEED {
            if let Ok(raw) = revision_feed(client, reqwest::Url::parse(DEFAULT_REFS)?, "https://raw.githubusercontent.com/stoveez/PlazCodeneww", limit).await { return Ok(raw); }
        }
        let mut feed = reqwest::Url::parse(url)?;
        if url == DEFAULT_FEED { let bucket=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH)?.as_secs()/2;feed.query_pairs_mut().append_pair("plazcode_check",&bucket.to_string()); }
        fetch_feed(client, feed, limit).await
    }).await.map_err(|_| anyhow::anyhow!("Release check timed out."))?
}
async fn run(install: bool, background: bool) -> anyhow::Result<()> {
    let root=folder();
    let source=std::fs::read(root.join("update-source.json")).ok().and_then(|raw| serde_json::from_slice::<Value>(&raw).ok());
    let url=source.as_ref().and_then(|value| value["feedUrl"].as_str()).filter(|url| !url.is_empty()).unwrap_or(DEFAULT_FEED);
    anyhow::ensure!(reqwest::Url::parse(url)?.scheme()=="https", "Update feed must use HTTPS.");
    progress(0,"Checking for updates…");
    let client=HTTP_CLIENT.as_ref().map_err(|error| anyhow::anyhow!("Update client could not start: {error}"))?;
    let raw=current_feed(client, url, feed_timeout(background)).await?;
    anyhow::ensure!(raw.len()<=65536,"Release feed is too large.");
    let feed: Value = serde_json::from_slice(&raw)?;
    let (latest,download,hash)=validate(&feed)?;
    if let Some(previous) = state().latest.as_ref() { anyhow::ensure!(version(&latest)? >= version(previous)?, "Release source returned an older cached version; retaining the latest known release."); }
    let notes = feed.get("release_notes").and_then(|value| serde_json::from_value::<Vec<ReleaseNotes>>(value.clone()).ok());
    let available=version(&latest)? > version(&installed())?;
    { let mut s=state();s.installed=installed();s.latest=Some(latest.clone());s.available=available;s.checked_at=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap_or_default().as_millis() as u64;s.check_error=None; if let Some(notes) = notes { s.release_notes = notes; } }
    if !available { progress(100,"Already up to date.");return Ok(()); }
    if !install { progress(0,"A newer version is ready to install.");return Ok(()); }
    #[cfg(not(windows))] anyhow::bail!("Installing desktop updates requires Windows.");
    #[cfg(windows)] {
        use std::os::windows::process::CommandExt;
        let helper=root.join("Update-PlazCode.ps1");anyhow::ensure!(helper.is_file(),"Update-PlazCode.ps1 is missing.");
        let stage=std::env::temp_dir().join(format!("PlazCode-download-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH)?.as_millis()));
        std::fs::create_dir_all(&stage)?;let path=stage.join("release.zip");
        let response=client.get(download).send().await?.error_for_status()?;
        let total=response.content_length().unwrap_or(0);anyhow::ensure!(total<=64*1024*1024,"Release is too large.");
        let mut file=tokio::fs::File::create(&path).await?;let mut stream=response.bytes_stream();let mut bytes=0u64;
        while let Some(chunk)=stream.next().await { let chunk=chunk?;bytes+=chunk.len() as u64;anyhow::ensure!(bytes<=64*1024*1024,"Release exceeds 64 MB.");file.write_all(&chunk).await?;
            progress(if total>0 { ((bytes*85/total).min(85)) as u8 } else { 35 },"Downloading update…"); }
        file.flush().await?;drop(file);progress(90,"Verifying and installing. PlazCode will close and relaunch…");
        let mut helper_process = std::process::Command::new("powershell.exe").args(["-NoProfile","-ExecutionPolicy","Bypass","-File"]).arg(helper).arg("-ZipPath").arg(path).arg("-ExpectedSha256").arg(hash).arg("-ExpectedVersion").arg(latest).arg("-ShowProgress")
            .current_dir(&root).creation_flags(0x08000000).spawn()?;
        let result = tokio::task::spawn_blocking(move || helper_process.wait()).await??;
        anyhow::ensure!(result.success(), "Updater could not complete installation. Review the updater error window and retry.");
        progress(100,"Updater finished. Reload the extension and refresh AI chat tabs.");
    }
    Ok(())
}
pub fn start_checker() {
    tokio::spawn(async {
        let mut interval = tokio::time::interval(Duration::from_secs(2));
        interval.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
        loop {
            interval.tick().await;
            { let mut s=state(); if s.busy || MANUAL_WAITERS.load(std::sync::atomic::Ordering::SeqCst)>0 { continue; } s.busy=true; s.background=true; }
            let result=run(false, true).await;
            let mut s=state();
            if let Err(error)=result { s.check_error=Some(error.to_string()); }
            s.busy=false;s.background=false;
        }
    });
}
pub async fn get() -> Json<Status> { Json(state().clone()) }
pub async fn post(Json(value): Json<Value>) -> axum::response::Response {
    let install=match value["action"].as_str() { Some("check")=>false,Some("install")=>true,_=>return (axum::http::StatusCode::BAD_REQUEST,Json(serde_json::json!({"error":"Unknown update action."}))).into_response() };
    let silent=!install && value["background"].as_bool().unwrap_or(false);
    // A manual request waits for the current background read, rather than competing with it.
    let _manual_waiter=if !silent { MANUAL_WAITERS.fetch_add(1,std::sync::atomic::Ordering::SeqCst);Some(ManualWaiter) } else { None };
    let wait_until=tokio::time::Instant::now()+Duration::from_secs(35);
    while !silent && { let s=state();s.busy && s.background } && tokio::time::Instant::now()<wait_until { tokio::time::sleep(Duration::from_millis(50)).await; }
    { let mut s=state();if s.busy { return (axum::http::StatusCode::CONFLICT,Json(serde_json::json!({"error":"An update is already running."}))).into_response(); }s.busy=true;s.background=silent;if !silent{s.error=None;s.progress=0;s.message="Checking for updates…".into();} }
    tokio::spawn(async move { let result=run(install, silent).await;let mut s=state();if let Err(error)=result { if !install { s.check_error=Some(error.to_string()); }if !silent{s.error=Some(error.to_string());s.message="Update failed. Your installed files were not changed by the downloader.".into();} }s.busy=false;s.background=false; });
    Json(serde_json::json!({"ok":true})).into_response()
}
#[cfg(test)] mod tests {
    use super::*;
    #[tokio::test] #[ignore = "live public repository request"] async fn public_revision_feed_is_current() {
        let mut builder=reqwest::Client::builder();
        if let Ok(path)=std::env::var("SSL_CERT_FILE") { builder=builder.add_root_certificate(reqwest::Certificate::from_pem(&std::fs::read(path).unwrap()).unwrap()); }
        let client=builder.build().unwrap();
        let raw=revision_feed(&client,reqwest::Url::parse(DEFAULT_REFS).unwrap(),"https://raw.githubusercontent.com/stoveez/PlazCodeneww",Duration::from_secs(30)).await.unwrap();
        let value:Value=serde_json::from_slice(&raw).unwrap();
        let (latest,_,_)=validate(&value).unwrap();
        assert!(version(&latest).unwrap()>=version("1.18.101").unwrap());
        println!("Live revision feed: {latest}");
    }
    #[test] fn reference_packets_are_exact_and_bounded() {
        let sha="a".repeat(40);let packet=format!("{sha} refs/heads/main\0capabilities\n");
        let raw=format!("001e# service=git-upload-pack\n0000{:04x}{packet}0000",packet.len()+4);
        assert_eq!(advertised_main(raw.as_bytes()).unwrap(),sha);
        assert!(advertised_main(b"0008abc").is_err());assert!(advertised_main(b"0004").is_err());
        assert!(advertised_main(&vec![b'a';131073]).is_err());
        let packet="not-a-sha refs/heads/main\n";assert!(advertised_main(format!("{:04x}{packet}",packet.len()+4).as_bytes()).is_err());
    }
    #[tokio::test] async fn new_revision_bypasses_stale_branch_feed_and_reuses_unchanged_metadata() {
        use tokio::io::{AsyncReadExt,AsyncWriteExt};
        let listener=tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();let base=format!("http://{}",listener.local_addr().unwrap());
        let server=tokio::spawn(async move {
            let mut paths=Vec::new();let mut discovery=0;
            for _ in 0..5 {
                let (mut socket,_)=listener.accept().await.unwrap();let mut request=Vec::new();
                while !request.ends_with(b"\r\n\r\n") {let mut byte=[0];assert_eq!(socket.read(&mut byte).await.unwrap(),1);request.push(byte[0]);}
                let request=String::from_utf8(request).unwrap();let path=request.split_whitespace().nth(1).unwrap().to_owned();paths.push(path.clone());
                let body=if path.starts_with("/refs") {
                    discovery+=1;let sha=if discovery<3 {"a".repeat(40)} else {"b".repeat(40)};
                    let record=format!("{sha} refs/heads/main\n");format!("{:04x}{record}0000",record.len()+4)
                } else {
                    assert!(path.contains(&"a".repeat(40)) || path.contains(&"b".repeat(40)));assert!(!path.contains("/main/"));
                    let version=if path.contains(&"a".repeat(40)) {"1.18.101"}else{"1.18.102"};
                    serde_json::json!({"version":version,"url":"https://example.com/update.zip","sha256":"c".repeat(64)}).to_string()
                };
                socket.write_all(format!("HTTP/1.1 200 OK\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}",body.len()).as_bytes()).await.unwrap();
            }paths
        });
        let client=reqwest::Client::builder().no_proxy().build().unwrap();let refs=reqwest::Url::parse(&format!("{base}/refs")).unwrap();
        for expected in ["1.18.101","1.18.101","1.18.102"] {
            let raw=revision_feed(&client,refs.clone(),&base,Duration::from_secs(1)).await.unwrap();let value:Value=serde_json::from_slice(&raw).unwrap();assert_eq!(value["version"],expected);
        }
        let paths=server.await.unwrap();assert_eq!(paths.iter().filter(|path|path.starts_with("/refs")).count(),3);assert_eq!(paths.len(),5);
    }
    #[test] fn automatic_check_progress_stays_quiet() {
        let previous=state().clone();
        {let mut s=state();s.background=true;s.message="A newer version is ready to install.".into();s.progress=100;}
        progress(0,"Checking for updates…");assert_eq!(state().message,"A newer version is ready to install.");assert_eq!(state().progress,100);
        {state().background=false;}progress(0,"Checking for updates…");assert_eq!(state().message,"Checking for updates…");assert_eq!(state().progress,0);
        *state()=previous;
    }
    #[test] fn installed_version_supports_split_and_legacy_packages() {
        let root=std::env::temp_dir().join(format!("plazcode-layout-{}",std::process::id()));
        std::fs::create_dir_all(root.join("PlazCode-Extension")).unwrap();
        std::fs::write(root.join("manifest.json"),r#"{"version":"1.18.94"}"#).unwrap();
        assert_eq!(installed_at(&root),"1.18.94");
        std::fs::write(root.join("PlazCode-Extension/manifest.json"),r#"{"version":"1.18.95"}"#).unwrap();
        assert_eq!(installed_at(&root),"1.18.95");
        std::fs::remove_file(root.join("manifest.json")).unwrap();
        assert_eq!(installed_at(&root),"1.18.95");
        std::fs::remove_dir_all(root).unwrap();
    }
    #[tokio::test] async fn checks_reuse_connection_and_bound_stalled_feeds() {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};
        assert_eq!(feed_timeout(true),Duration::from_secs(8));
        assert_eq!(feed_timeout(false),Duration::from_secs(30));
        let listener=tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let url=reqwest::Url::parse(&format!("http://{}/feed",listener.local_addr().unwrap())).unwrap();
        let server=tokio::spawn(async move {
            let (mut socket,_)=listener.accept().await.unwrap();
            for _ in 0..2 {
                let mut request=Vec::new();
                while !request.ends_with(b"\r\n\r\n") {
                    let mut byte=[0];assert_eq!(socket.read(&mut byte).await.unwrap(),1);request.push(byte[0]);
                }
                socket.write_all(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: keep-alive\r\n\r\n{}").await.unwrap();
            }
        });
        let client=reqwest::Client::builder().no_proxy().build().unwrap();
        for _ in 0..2 {assert_eq!(fetch_feed(&client,url.clone(),Duration::from_secs(1)).await.unwrap(),b"{}");}
        server.await.unwrap();
        let listener=tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let url=reqwest::Url::parse(&format!("http://{}/stalled",listener.local_addr().unwrap())).unwrap();
        let server=tokio::spawn(async move {let (_socket,_)=listener.accept().await.unwrap();tokio::time::sleep(Duration::from_secs(2)).await;});
        let started=tokio::time::Instant::now();
        assert!(fetch_feed(&client,url,Duration::from_millis(30)).await.is_err());
        assert!(started.elapsed()<Duration::from_secs(1));server.abort();
    }
    #[test] fn release_validation_and_versions() {
        assert!(version("1.18.80").unwrap()>version("1.18.79").unwrap());assert_eq!(version("1.18.80").unwrap(),version("1.18.80.0").unwrap());assert!(version("bad").is_err());
        assert!(validate(&serde_json::json!({"version":"1.18.80","url":"http://example.com/a.zip","sha256":"a".repeat(64)})).is_err());
        assert!(validate(&serde_json::json!({"version":"1.18.80","url":"https://example.com/a.zip","sha256":"bad"})).is_err());
        assert!(validate(&serde_json::json!({"version":"1.18.80","url":"https://example.com/a.zip","sha256":"a".repeat(64)})).is_ok());
    }
}
