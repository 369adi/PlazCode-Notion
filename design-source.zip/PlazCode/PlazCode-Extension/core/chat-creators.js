const PlazCodeChatCreators = (() => {
  'use strict';
  const policy = 'CHAT MODEL/UI CREATION: When asked to make a Roblox model or UI, automatically use PlazCode creation_preview in this chat; no desktop navigation is needed. Read relevant saved creator feedback, save a shape/layout pass, then bounded stable-ID detail patches. Use the headless_build blueprint schema, actual Roblox materials, world-space part centers and native UI properties. Each save is at most 120 nodes/55,000 characters, total at most 800 nodes. Save status ready only after validation and finish detailing. A RobloxScript model/UI creation request defaults to Studio insertion unless explicitly preview/draft/planning/export-only. Call creation_insert with the saved build_id and exact current revision, then verify the returned result and inspect/playtest relevant behavior. Never recreate the design independently in Luau: insertion uses the saved preview blueprint. Preview-only, draft-only, planning, export-only and do-not-insert requests MUST NOT insert. The desktop Create preview flow explicitly remains preview-only until Insert is chosen. Revise the same saved build for follow-up visual changes; preserve unrelated instances and gameplay scripts. Existing script bug fixes, gameplay logic and edits to unrelated existing UI/models use their normal tools. Creator preview rendering approximates Studio lighting/materials/fonts/layout; identical blueprint properties are not a promise of pixel-identical rendering. Studio insertion success must come from confirmed tool results.';
  const tool = {
    name: 'creation_insert', server: 'roblox',
    description: 'Insert a READY saved PlazCode creator model/UI directly from this chat using its exact blueprint and revision. No desktop Insert button is required. Use after creation_preview for Studio creation requests; never for preview-only requests. Uses bounded, owned, exactly-once Studio passes; inspect partial/ambiguous failures before retrying.',
    inputSchema: {type:'object',required:['build_id','revision','action_id'],additionalProperties:false,properties:{
      build_id:{type:'string',description:'The saved creation_preview build_id.'},
      revision:{type:'integer',description:'Exact revision returned by the latest save/read.'},
      action_id:{type:'string',description:'Unique 1–64 character insertion ID (letters, digits, dot, dash, underscore). Reuse the same ID only for the same insertion outcome.'}
    }}
  };
  function previewOnly(text) {
    return /\b(?:preview[ -]only|draft[ -]only|export[ -]only|(?:do not|don['’]?t|never)\s+insert|(?:do not|don['’]?t|never)\s+(?:modify|change)\s+(?:Roblox\s+)?Studio)\b/i.test(String(text||'')) || /\b(?:just|only)\s+(?:a\s+)?(?:preview|draft|plan)\b/i.test(String(text||''));
  }
  function routeRequest(text) {
    const request=String(text||'').replace(/```[\s\S]*?```/g,' ').trim();
    if(request.length>40000 || /^(?:how\b|explain\b|what\b|why\b|can (?:i|someone)\b)/i.test(request))return '';
    const creation=/\b(?:make|build|create|generate|design|recreate)\b/i.test(request);
    const visual=/\b(?:ui|gui|hud|user interface|interface|model|3d model|shop menu|inventory menu|settings menu)\b/i.test(request);
    if(!creation || !visual || /\b(?:machine learning|language model|data model|view model|database model)\b/i.test(request))return '';
    return policy+'\nAvailable chat insertion command: '+JSON.stringify(tool)+'\nContinue the current request through the creator tools. Preserve explicit preview-only and placement instructions; do not restart the agent.';
  }
  function batches(blueprint) {
    const draft=PlazCodeCreator.clone(blueprint);
    for(const node of draft.nodes||[]){if(node.id===draft.root_id && node.parent==='')delete node.parent;if(node.name==='')delete node.name;}
    return PlazCodeCreator.batches(draft);
  }
  function create(env) {
    const outcomes = new Map();
    let busy = false;
    function insert(args) {
      const context = env.context();
      if(!args || typeof args.build_id!=='string' || !args.build_id || args.build_id.length>96 || !Number.isSafeInteger(args.revision) || args.revision<1 || !/^[a-zA-Z0-9_.-]{1,64}$/.test(args.action_id||'') || Object.keys(args).some(key=>!['build_id','revision','action_id'].includes(key)))return Promise.resolve({ok:false,error:'Supply build_id, an exact positive revision and a valid unique action_id. No Studio command was sent.'});
      const key = context+'|'+args.action_id;
      const signature = JSON.stringify([args.build_id,args.revision]);
      if(outcomes.has(key)) {
        const previous=outcomes.get(key);
        return previous.signature===signature ? previous.result : Promise.resolve({ok:false,error:'This insertion action_id already belongs to a different draft/revision. No Studio command was sent.'});
      }
      if(busy)return Promise.resolve({ok:false,error:'Another creator insertion is still running. No additional Studio command was sent.'});
      busy=true;
      const result=(async()=>{
        let done=0,total=0;
        const started=Date.now();
        const check=()=>{if(!env.allowed() || env.context()!==context || Date.now()-started>110000)throw Error('Insertion stopped or chat/engine changed. Inspect Studio before retrying.');};
        try {
          check();
          const response=await env.read(args.build_id);
          check();
          if(!response?.ok || !response.record)throw Error(response?.error||'Saved creator draft is unavailable.');
          const record=response.record;
          if(record.revision!==args.revision)throw Error('Draft changed. Read the latest revision before inserting.');
          if(record.status!=='ready')throw Error('Finish the draft and save status ready before inserting; partial/building drafts are not inserted automatically.');
          if(record.blueprint?.build_id!==args.build_id)throw Error('Saved build identity does not match.');
          const draft=PlazCodeCreator.clone(record.blueprint);
          const passes=batches(draft);
          total=passes.length;
          for(let index=0;index<passes.length;index++) {
            check();
            const current=await env.read(args.build_id);
            check();
            if(!current?.ok || current.record?.revision!==args.revision || current.record?.status!=='ready')throw Error('Saved draft changed during insertion.');
            const pass={...passes[index],action_id:'chat-'+args.action_id+'-'+index};
            const compiled=ZSHeadlessBuilder.compile(pass);
            if(!compiled.ok)throw Error(compiled.error);
            const outcome=await env.execute(compiled);
            if(!outcome?.ok || outcome.payload?.ok!==true || outcome.payload.build_id!==draft.build_id || outcome.payload.action_id!==pass.action_id || outcome.payload.ownership_verified===false)throw Error(outcome?.error||outcome?.payload?.error||'Studio did not confirm this insertion pass.');
            done++;
            check();
          }
          const final=await env.read(args.build_id);
          check();
          if(!final?.ok || final.record?.revision!==args.revision)throw Error('Saved draft changed before insertion verification completed.');
          return {ok:true,build_id:draft.build_id,revision:args.revision,nodes:draft.nodes.length,passes:done,root_path:draft.target_parent+'.'+draft.root_name,studio_changed:true,blueprint_source:'exact saved creator revision',message:'Saved model/UI inserted through validated owned passes. Review Studio rendering and test gameplay/UI behavior.'};
        }catch(error){return {ok:false,build_id:args.build_id,revision:args.revision,completed_passes:done,total_passes:total,studio_changed:done>0,completion_uncertain:total>0,error:String(error.message||error)+' Finished/uncertain passes must be inspected before another insertion.'};}
        finally {busy=false;}
      })();
      outcomes.set(key,{signature,result});
      if(outcomes.size>100)outcomes.delete(outcomes.keys().next().value);
      return result;
    }
    return {insert};
  }
  return {policy,tool,routeRequest,previewOnly,batches,create};
})();
if(typeof module!=='undefined')module.exports=PlazCodeChatCreators;
