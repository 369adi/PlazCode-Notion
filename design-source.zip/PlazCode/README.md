PlazCode 1.19.16 — Workspace design upgrade and new themes

A visual refinement built on the existing workspace layout, with smoother interaction tweens, clearer controls and five new shared themes. Startup update detection also receives dedicated macOS feed freshness protection.

- Five shared themes: Oceanic, Copper Atelier, Aurora, Orchid Noir and Solar Dusk. Each colors the complete desktop surface system, browser bar and extension popup.
- Named theme preview tiles with visible selection and keyboard focus states.
- Workspace card spacing, rounded surfaces, session hierarchy, navigation feedback and form styling build on the existing desktop design.
- Short CSS hover, press and page-entry tweens add interaction feedback without new animation libraries, timers or DOM observers.
- Reduced-motion settings disable desktop transitions and animations, including the update spinner. Existing glow and gradient controls still apply.
- Normal app launch and reopening an existing app instance request automatic installation when a newer published version is detected.
- New palettes stay synchronized across desktop preferences, browser overlays and popup appearance.
- The dedicated macOS release feed now uses the same commit-pinned freshness lookup and cache-busting fallback as the normal feed. Platform feed cache entries cannot reuse another platform payload.

## PlazCode 1.19.15: Create models and UI directly in chat

- Asking an active RobloxScript AI chat to make a model or UI uses PlazCode's saved creator workflow. The desktop creator page does not need to be opened.
- The AI saves shape/layout and detail passes with creation_preview, then calls creation_insert with the exact ready draft revision for Studio creation requests.
- Insertion reads the saved blueprint rather than recreating it in Luau. Geometry, hierarchy and supported properties use the same validated compiler.
- Preview-only/draft-only requests stay out of Studio. The desktop Create preview flow remains preview-only. Existing script repairs and AgentScript retain their normal tools.
- Duplicate insertion calls retain their outcome; stale drafts, concurrent insertion, Stop, chat/engine changes and unconfirmed Studio results are handled explicitly. Finished/uncertain passes require inspection before retrying.
- Saved root-parent and absent-name normalization is repaired in the chat insertion path without changing the stored draft.

This extension-only update retains the signed 1.19.14 Windows/macOS native components. Studio rendering can differ from the creator preview; data parity does not promise pixel-identical lighting, materials, fonts or advanced layouts. Live signed-in AI chats and real Studio insertion remain unverified.

- Each GitHub release offers PlazCode-VERSION.zip for Windows and PlazCode-macOS-VERSION.zip for Mac. The normal package retains compatibility with older shared-feed Mac updaters. Mac setup/start launchers select latest-macos.json and preserve custom feed settings.

Reload the extension AND refresh open AI tabs after updating.

## PlazCode 1.19.14: Creators, native macOS and launch updates

### Model and UI creators

- A compact prompt row, Preview/Blueprint tabs, export/insert controls above the preview, and an "Ask for a change…" row below it.
- Models: Realistic, Low poly, Cartoon and Blocky styles; shape/detail passes; part colour/material edits; undo; recolour; resize; ground alignment; optional welded insertion; .rbxmx and preview PNG export.
- UI: Phone/Tablet/PC preview, list/grid layout support, gradients, readability/tap-target checks and optional hover/click/panel animations.
- Saved drafts and explicit likes/improvement notes inform later creation prompts. Revisions target stable node IDs instead of replacing the complete build.
- Use an active RobloxScript chat to Generate, revise or Insert. AgentScript remains available for ordinary project work. Draft previews do not modify Studio until you choose Insert.

### Desktop updates and macOS

- Desktop launch checks quietly and installs the latest complete release directly when outdated. The app shows progress for the actual download/install; extension reload and chat-tab refresh remain manual.
- A native universal macOS app supports Apple Silicon and Intel. macOS launchers, StudioMCP discovery, startup locking and file/browser opening have platform-specific handling.
- Creator drafts join settings, memory, templates and MCP configuration outside the replaceable installation. Corrupt creator libraries are reported rather than overwritten.

### Scope and validation

Creation uses the current browser AI, with bounded completed build passes rather than token-by-token rendering. Advanced UI layouts, live Studio appearance and reference fidelity still require Studio review. The Mac app is ad-hoc signed, not Developer ID notarized; first-launch approval may be required. Native automated tests do not establish live signed-in AI-site, desktop GUI or Roblox Studio compatibility.

After updating, reload the extension AND refresh open AI tabs.

## PlazCode 1.19.13: Stable mode switching and manual work folding

- Completed Working/Worked sections retain your chosen expanded or folded state. Click their heading to fold or reopen them manually.
- Storage and message notifications for the same script-mode change no longer reset the connection twice. Retired sockets are detached before reconnecting, and stale startup settings cannot reverse a recent manual choice.
- Double-clicking a mode segment no longer cycles back. Transitional disconnected status is held behind the Switching message until the new connection settles.
- Arena has no custom Working/Worked foldout; its replies and tool execution remain available. ChatGPT and Notion exclusions remain unchanged.
- Claude hides single command frames including CodeMirror content and language-label paragraphs, preserving narration, ordinary code, thinking and message actions.

Reload the extension AND refresh open AI tabs after updating. Saved settings, memory, templates and MCP configuration remain preserved.

## PlazCode 1.19.12: Consistent package versions and current release checks

- Sidebar, title, Settings and Updates display the same installed package version. An independently versioned app binary no longer produces a contradictory outdated badge.
- BAT update checks request uncached current release metadata. Both update paths select the latest complete package directly, including across multiple skipped releases.
- Native build and extension are both 1.19.12 in this package. Existing settings, memory, templates and MCP configuration remain preserved.
- BRANDING-NOTICE.txt identifies the official repository/release channel and distinguishes unofficial modified distributions. Existing GPL and third-party licenses remain unchanged. This notice and update SHA256 verification do not prevent copying or modification.

Reload the extension AND refresh open AI tabs after updating.

## PlazCode 1.19.11: Urgent tool-result loop fix

- Fixed `toSend is not defined`, which interrupted normal tool-result delivery after a command executed.
- Outgoing feedback is initialized directly from the completed result. Successful results, formatted errors and screenshots retain their send path and changed-memory context.
- Periodic command-list reminders remain disabled. Existing repeated-failure pause, startup, Stop and recovery behavior remain intact.
- Extension-only hotfix: the native executable remains the unchanged 1.19.10 binary; no Rust/agent rebuild was required.

Reload the extension AND refresh open AI tabs after updating. Settings, memory, templates and MCP configuration remain preserved. Do not assume a command was undone because the old result-delivery error appeared; inspect its result/project state before repeating a mutation.

## PlazCode 1.19.10: Notion startup status and meaningful chat continuation

- Startup command outcomes survive Notion settling under a replacement event anchor. Matching stays scoped to the conversation, original assistant position, preceding user message and command text; later identical commands remain distinct.
- Bootstrap identity is captured before card rendering, and restored completed/error outcomes also prevent re-dispatch.
- Notion result attachments use `plazcode_tool_result_*.txt` and tell the AI to continue the existing handshake or task. The second attachment is the command result, not a second startup.
- New-chat continuation is offered only for chats with real user requests or pending follow-ups. Startup-only records, including legacy exports, are excluded.

Reload the extension AND refresh open AI tabs after updating. Saved settings, memory, templates and enabled MCP servers remain preserved.

## PlazCode 1.19.09: Normal chat flow and targeted command recovery

- Normal replies release the composer before checkpoint bookkeeping. Notion retains its pre-send response identity; stale/duplicate send callbacks cannot start another loop.
- Idle Co-work messages use the site’s normal composer/send path, matching Co-work Off. Active follow-ups keep their existing queue and safe-boundary delivery.
- Removed periodic command-list reminders, full-prompt riders and idle reminder sends. Changed memory context remains supported.
- Explicit command-access refusal triggers a connected-engine check and one same-chat restart handshake, then resumes the unfinished request. Stop, changed chat/engine, disconnected engine and unsent drafts prevent recovery. A repeated refusal stops rather than repeatedly restarting.
- Delayed injection cleanup cannot clear a newer send, and stale cover requests cannot block an idle composer.
- Display versions use 1.19.09, 1.19.10 … 1.19.99, then 1.20.00. Internal Chrome/native versions remain 1.19.9, 1.19.10 … 1.20.0 for valid update comparisons.

Reload the extension AND refresh open AI tabs after updating. Settings, memory, templates and enabled MCP servers retain their preservation rules.

## PlazCode 1.18.109: Stable startup and session reminders

- Automatic context reminders preserve the active task and follow-ups. They no longer reissue the startup handshake, request a readiness reply or wait for a new first request. This applies to both engines and both reminder paths.
- Startup list_commands is recorded before execution and its confirmed result survives message replacements, preventing stale “not run” cards and watchdog replay.
- Notion uses its stable transcript row to identify commands. Pending navigation startup is cleared on composer preparation or an active session; delayed requests check again before starting.
- Duplicate Start on an already-started populated chat is harmless. Explicit Restart and fresh-chat startup remain available.
- Working/Worked progress circles continue to reflect explicit assistant Plan/Checklist steps; unknown totals animate. Custom grouping remains disabled for Notion and ChatGPT.

Reload the extension AND refresh open AI tabs after updating. Saved settings, memory, templates and enabled MCP servers retain their existing preservation rules.

## PlazCode 1.18.108: Work indicators and Notion startup controls

- Removes the empty bordered bar beneath expanded Working/Worked headings. Waiting text clears when a real reply arrives.
- Disables custom browser chat foldouts and bar work indicators on Notion and ChatGPT; other supported sites keep them.
- Working circles fill with explicit assistant Plan/Checklist checkbox progress. Unknown totals stay animated, successful completion fills the ring, and interrupted work keeps its partial state.
- Notion startup locks input before composer preparation, guards typing/paste/drop/Send across remounts, and covers a bounded composer card. Internal writes, copy, navigation and Stop remain available.
- Protocol upload no longer opens Notion’s general plus menu. Existing file-input/direct-drop upload, exact content, single-send confirmation and owned cleanup remain required.

Reload the extension AND refresh open AI tabs after updating.

## PlazCode 1.18.107: Visible paused work and accurate Co-work state

- Interrupted, stopped and budget-paused work stays expanded, so replies remain visible. Completed work still folds and can be reopened; ChatGPT keeps its native presentation.
- Work messages only fold when their expandable heading is successfully mounted. Missing or failed headings leave the original messages visible, and temporary mount failures retry.
- Co-work Off hides the empty queue panel and stale Paused/Resume buttons. Stop does not pause an empty disabled queue; real pending requests remain saved and reviewable.
- The Notion startup provider confirmed working by the user is unchanged. All other provider files are also unchanged.

Reload the extension AND refresh open AI tabs after updating.

## PlazCode 1.18.106: Notion uploaded-file preview recognition

- Fixes the supplied visible-file timeout: Notion protocol cards may be siblings of the smaller editor/send frame or show a shortened filename. Attachment inspection now stays within the bounded composer shell and recognizes those labels.
- Upload readiness waits for busy indicators on detected file cards. Stop cleanup supports the owned card’s Close or small unlabeled icon button.
- Complete protocol text, one acknowledged send, preserved foreign drafts and exact-name delayed cleanup remain required. ChatGPT, Claude and DeepSeek providers are unchanged.

Reload the extension AND refresh open AI tabs. Remove any old failed-upload card before retrying. Live signed-in Notion startup remains unverified.

## PlazCode 1.18.105: Notion upload and Claude command cards

- Fixes the reported startup crash: Notion page drag handlers could not see transfer types/files on generic events dispatched by the extension. Upload fallback now uses native DragEvent fields.
- Ends the drop sequence with dragleave so the site can reset its drag overlay and cursor.
- Claude hides the empty JSON label/border around a tool command, preserving adjacent narration, thinking, normal code and response actions.
- Full protocol files, confirmed uploads, one acknowledged send, Stop cleanup and existing draft preservation remain unchanged.

Reload the extension AND refresh all open AI tabs. Live Notion startup remains unverified; this release fixes the specific supplied drag-event exception.

## PlazCode 1.18.104: Animated installer and Notion protocol files

- A rounded dark installer window with PlazCode orange gradients, an animated shimmer and swirl, stage text and real file-copy progress.
- The installer UI runs on its own STA message loop so download, verification, backup, extraction and process waits cannot freeze its animation. File replacement progress advances from actual completed file counts.
- Notion long protocol messages use one named .txt file containing the complete original text, plus a short native composer instruction. Upload readiness and one confirmed send are required; text is not truncated.
- Notion no longer retries a 33k+ text paste that the site converts into a Pasted text attachment. Existing draft attachments are preserved and receive a specific fresh-chat/remove-draft explanation. Stopped owned uploads are cleaned up.
- Short protocol messages retain the native composer path. Saved settings, MCP configuration, memory, templates, installation process scope, checksums and rollback behavior are preserved.

The refreshed helper window is used after this version is installed; the already-installed old helper can still appear during the update to 1.18.104. Notion remains experimental until live startup is confirmed. Open a fresh Notion AI chat if old Pasted text draft cards remain. Reload the extension AND refresh existing AI tabs after updating.

## PlazCode 1.18.103: Notion controlled paste and Co-work

- Notion sends complete startup and tool-result text through one literal controlled paste transaction, verifies retention through two renders, and commits at most once. No prompt truncation or repeated tiny inserts.
- Co-work uses Follow up in the native composer while enabled, including idle time and after Stop. Internal startup/tool injection retains its temporary input mask. Turning Co-work off restores the original placeholder.
- Notion no longer uses bulk execCommand or direct React-owned DOM replacement as the large-send fallback. Short native edits rely on Chromium input events instead of duplicate synthetic model events.
- Notion input cover targets only the editable, preventing a growing ancestor from becoming the click-blocking mask. Start on a populated AI landing first opens a fresh chat.

Notion remains experimental: simulated model/DOM tests cannot confirm live Notion behavior. After updating, reload the extension AND refresh all open AI tabs.

## PlazCode 1.18.102: Updates, Stop, Notion and Co-work

- The default GitHub updater checks the current repository revision every two seconds and fetches metadata by immutable commit. Unchanged metadata is reused; quiet automatic checks and the eight-second request budget remain. Custom feeds retain their configured path. Network delays and browser suspension still apply; this is not guaranteed instant push.
- Notion large startup drafts use one complete native beforeinput/insertText/input write instead of chunked clipboard pastes. Editable/readonly attributes are temporarily restored during the write, focus is acquired after unlocking, and the complete draft must survive two renders before Send.
- Co-work tracks placeholder nodes introduced by composer remounts, and ChatGPT Work literal placeholder labels display Follow up without changing user text or replacing the native input.
- Stop releases the composer immediately and prevents late work from restoring the Agent is working cover until a new user action resumes work. Tool cancellation and Safe/Immediate semantics remain unchanged.
- PlazCode Working/Worked transcript summaries and bar disclosure are disabled on ChatGPT. Activity records remain available to desktop; other providers retain their collapsible groups.
- Default update checks avoid the cached mutable branch feed when current revision discovery succeeds. Older cached metadata cannot replace a newer known release.

Notion remains experimental. Native draft checks and placeholder/group tests use simulated DOMs; live Notion startup still needs confirmation.

After updating, reload the extension AND refresh every existing AI tab.

## PlazCode 1.18.101: Notion startup and engine switching

- All Notion literal pastes, including startup chunks, use escaped code HTML to avoid rich-text Markdown conversion. Complete normalized text must be retained before Send; sampled near-match acceptance is removed.
- The browser bar shows Switching while AgentScript/RobloxScript reconnects, disables Start, ignores old-engine status and restores actual health on completion or after an eight-second bound.
- A rejected retained large paste no longer falls into repeated tiny inserts and full rewrites. One initial empty hydration rejection may retry; partial failures stop without sending.
- Intentional engine reconnection does not flash a bridge-down banner. A genuine failure remains visible after the transition timeout.

Notion remains experimental. Tests use simulated rich-text imports and provider DOMs; live Notion startup still needs confirmation.

After updating, reload the extension AND refresh every existing AI tab.

## PlazCode 1.18.100: Browser bar startup and placement fix

- Fixed the 1.18.99 shared UI initialization order. When a composer already existed, placeholder state was read before initialization and startup aborted, leaving the bar missing or unpositioned. This affects multiple providers and Chromium browsers.
- ChatGPT anchors to the actual bounded composer card, rather than a full-page form or its inner text scroller. Existing DeepSeek/Claude/Notion placement rules are preserved.
- Desktop browser status now reports bar visible, bar hidden or refresh AI tab separately from bridge connectivity. A worker connection alone does not establish that the page UI loaded.
- Full content-script startup tests cover preloaded ChatGPT, DeepSeek, Claude and Notion composers. Native Co-work and Stop behavior are preserved. Live tester layouts still require confirmation.

After updating, reload the extension in chrome://extensions or edge://extensions AND refresh existing AI tabs.

## PlazCode 1.18.99: Native Co-work, continuation and reliability

- Co-work uses the existing ChatGPT, Claude, DeepSeek and Notion composer. While work is active, its placeholder becomes **Follow up**. Requests are accepted immediately and delivered at the next safe AI message boundary. Native Stop keeps its role. Unsent drafts are protected during tool feedback.
- Notion long startup/results use bounded, verified paste chunks rather than repeatedly pasting a large prompt as a text-file attachment. Startup still requires the list/ready acknowledgement; failed delivery stays stopped.
- New chats can offer **Yes, continue.** or **No, I wanna start a new project.** Context is loaded only after successful startup. Captured history is bounded to 2,000 messages / 800,000 text bytes per chat, 20 chats / 8 MB total; continuation is a shorter excerpt and can omit unloaded messages. Inspect current state before resuming uncertain actions.
- Shared command/time budgets pause before the next command; zero disables a limit. Export continuation or explicitly resume a paused task. Automatic Studio visual checks are bounded, optional and do not prove runtime correctness.
- Restore an individual captured local file or Studio script in Tasks. Restoration checks current contents first and refuses conflicting later edits. Studio script snapshots cover direct multi_edit/script_set_source edits in Edit mode and the same bridge session; arbitrary Luau mutations are not selectively restored.
- The extension toolbar popup now follows the desktop/bar palette, glow and gradient settings.
- Each update now creates a GitHub Release with both ZIPs and change notes.

Update in the desktop Updates tab or run Update-PlazCode.bat, then reload the extension and refresh AI tabs. Automated checks and the Windows build are verified; live Windows/Studio and live provider behavior still need target-machine confirmation.

## PlazCode 1.18.98: Cancellation settling guard

Includes all 1.18.97 features below. Keeps Immediate Stop latched while an interrupted tool is settling and blocks further tool dispatch during that interval. Safe Stop waits for the current tool step. Reload the extension and refresh AI tabs.

## PlazCode 1.18.97: Tray access, stop modes and cleaner work sessions

- Reopen the desktop app using its Windows tray icon. Right-click for Open or Quit. If tray registration fails, the app remains in the taskbar.
- **Immediate Stop is the default.** It stops generation and new actions, abandons tool waits, signals the active checkpoint, and cleans up command/helper processes owned by that operation. Partial changes can remain; external tools may not honor interruption. Inspect state before retrying.
- **Safe Stop** stops generation and new actions, then waits for the current tool step. The mode syncs between desktop and browser settings. Neither mode is an undo guarantee.
- Send images and video with a caption from desktop or the browser bar. Use native video when the selected site accepts it, or up to eight sampled frames. Frames do not include audio or continuous motion. Transfer limits are eight files / 12 MB; local conversion inputs are limited to 64 MB. Browser decoding is used first; an installed FFmpeg/FFprobe can handle additional codecs. Not every format or site is supported.
- Co-work preserves all unfinished goals and can interleave independent tasks at safe message boundaries. It does not create simultaneous AI reply streams.
- Work remains expanded while active and folds after finishing. ChatGPT action controls fold with their messages. Empty no-tools-used filler is removed, and live engine checks guard correction of false offline claims.

Update from the Updates tab or Update-PlazCode.bat, reload the extension, and refresh open AI tabs. Existing settings, memory and enabled MCP servers retain their data locations. Windows builds and automated checks are verified; live Windows tray behavior and live provider uploads still require testing on the target machine.

## PlazCode 1.18.96: Faster automatic release checks

Automatic update checks reuse HTTP connections instead of reopening them for
every check. A stalled automatic request times out after eight seconds and retries
in the background. Manual checks keep their 30-second timeout; download handling
and quiet background UI are preserved. GitHub propagation and network delays
still apply: this remains polling, not guaranteed instant push notifications.

Update with the desktop Updates tab or Update-PlazCode.bat. Reload the extension
and refresh open AI tabs afterwards. The corrected PlazCode/PlazCode-Extension
folder layout and desktop-only Tasks from 1.18.95 are retained.

## PlazCode 1.18.95: Separate app and browser extension folders

The main folder is PlazCode. Run PlazCode.exe there. In Chrome Load unpacked,
select PlazCode/PlazCode-Extension, which contains only the browser files.
The launcher, updater and desktop app stay in the main PlazCode folder.
Tasks is now desktop-only; its expandable header uses a clickable hand cursor.

Existing installations keep their current outer folder path. The automatic
update includes legacy extension copies for compatibility, so your currently
loaded extension keeps working. You can keep loading that existing folder;
new installations should select the nested PlazCode-Extension folder. Changing
Chrome's loaded folder creates a separate extension installation and may require
restoring browser-only preferences. Native settings, memory and enabled MCP
servers stay in their existing data locations. Reload the extension and refresh
open AI tabs after updating. No installation folders are renamed automatically.

## PlazCode 1.18.94: Studio MCP compatibility and clearer extension folder

PlazCode discovers Studio IDs for the updated Roblox MCP tools, while keeping local bridge startup independent of Studio readiness. Fresh-install ZIPs use PlazCode-Extension.

- Automatically supply studio_id for targeted Studio tools when one instance is connected. Cache discovery briefly, preserve explicit caller IDs, and require a deliberate selection when multiple instances are open. Older schemas are forwarded unchanged.
- Fresh installations extract into PlazCode-Extension. Update packages preserve the layout older updaters accept, and the updated installer accepts either single-root layout without changing the installed folder.
- The internal get_studio_state connection probe now receives studio_id when required. Missing IDs no longer prevent automatic Studio connection after the new MCP update.
- Studio auto-connect attempts have an eight-second bound and retry in the background; local bridge endpoints are bound before the desktop opens. Timed-out discovery never dispatches the requested Studio command.

Fresh installation: extract PlazCode-1.18.94.zip and select PlazCode-Extension with Chrome Load unpacked. Existing installations: use the Updates tab or Update-PlazCode.bat, then reload the extension and refresh AI tabs. Existing settings and folder paths remain intact.

## PlazCode 1.18.93: Shared themes, larger memory and quieter updates

- Desktop palette, glow and gradient settings sync through shared preferences to the browser bar, menus, controls and activity panels. Selections persist across restarts and updates; legacy browser themes map back to desktop palettes. Existing unsynced appearance is migrated without forcing a reset.

- Saved memory supports 150,000 characters total, with a capacity display, larger note fields and transactional storage limits. Long notes have previews and paged AI reads instead of being omitted or flooding startup prompts. Memory-only backups can load saved notes without sending an old conversation to the AI.

- Notion tool results paste as literal HTML code instead of Markdown-like rich text. Failed writes have wall-clock retry limits, preventing hundreds of timer-throttled chunk attempts. A failed draft is cleared only when it still matches the locked composer content captured by that send attempt.

DeepSeek’s desktop AI picker description now reads: Recommended for free users. Fast and reliable.

- Release checks run every two seconds, and desktop/browser status reads every second. The default GitHub cache key uses two-second buckets; network and publication delays still apply. This is polling, not guaranteed instant push.
- Automatic checks do not show Checking for updates… or disable the manual check/install buttons. Manual requests wait for an ongoing background read instead of racing it.

## PlazCode 1.18.92: Tasks close button and live Co-work follow-ups

Close Tasks reliably and send follow-ups during agent work without waiting for the entire task to finish.

- Co-work delivers new requests alongside the next tool result or continuation, preserving the current task and the order of follow-ups. Streaming responses and running commands are not interrupted.
- Follow-up status confirms receipt and explains delivery at the next safe message boundary. Unconfirmed sends remain paused for review rather than being blindly retried.
- Tasks has a dedicated sticky header and accessible close button, separated from content, with explicit button type and click handling.

# PlazCode — Roblox Studio + AgentScript AI agent

Turn any major AI chat (**DeepSeek, ChatGPT, Google Gemini, Kimi, GLM, Qwen, Arena, Crax GPT, or Ollama running locally**) into an autonomous development agent. Three switchable engines:

| Engine | Toggle | Target | Port |
|---|---|---|---|
| **Roblox** (RS) | — | Roblox Studio via its built-in MCP server | ws://127.0.0.1:17613 |
| **AgentScript** (AS) | — | A local project folder — files + terminal | ws://127.0.0.1:17615 |
| **Animation** (AN) | — | Roblox Studio scoped to the motion workflow | ws://127.0.0.1:17613 |

Describe what you want in plain English and the AI builds instances, writes Luau/code files, sculpts terrain, tunes lighting, generates UI, runs builds and tests, and audits your project — inside Studio or directly on disk.

No API keys, no monthly fees. Chromium browsers (Chrome, Brave, Edge, Thorium). The extension and desktop app use the same dark navy + warm gold PlazCode theme.

---

## Engines

- The bar above every supported chat composer carries a segmented **RS / AS / AN** toggle. Switching engines wipes tool caches so commands cannot cross engines.
- **RS** drives Roblox Studio through StudioMCP (stdio JSON-RPC spawned by `plazcode-agent`).
- **AS** gives the AI full control of ONE local folder ("the workspace") through native Rust tools — sandboxed paths, exact-match diff editing, glob/content search, and terminal execution with hard timeouts.
- **AN** rides the same Roblox bridge as RS but steers the system prompt into the animation_* workflow.

Large `execute_luau` scripts are auto-chunked around 24 KB so Studio's parser never hits the ~64 KB wall. Each chunk is still one NDJSON/JSON-RPC line.

---

## Setup

1. Open `chrome://extensions` → Developer mode → **Load unpacked** → this folder (`manifest.json`).
2. Double-click **`PlazCode.exe`**. `PlazCode.exe --headless` runs without the desktop window. It starts:
   - HTTP API on `http://127.0.0.1:3000`
   - WS bridges on `17613` (RS/AN) and `17615` (AS)
   - Workspace folder for AgentScript (`PLAZCODE_WORKSPACE_ROOT` / `--workspace` / `%USERPROFILE%\PlazCodeWorkspace`)
3. **RS/AN:** Roblox Studio → Assistant AI → ⋯ → Manage MCP Servers → Enable Studio as MCP Server.
4. Open a supported chat and click **Start agent**.

---

## Agent

- Native crate: `agent/` (`plazcode-agent` 1.18.86). Desktop control center, MCP helper spawn, outbound WS channel so ping/status keep flowing during a 20 s `execute_luau`.
- Service worker skips stale-socket reconnect and MCP heal while a `call_tool` is in flight (the 25 s stale window used to kill long tools).
- 30 Studio skills, a 24-command animation suite, AgentScript file/terminal tools.
- Personas (Builder / Scripter / Animator / Fixer), Extra Thinking, Forge GUI, Image → Model, auto-fix playtest errors.

---

## Testing

```bash
node test-skills.js
node test-parser.js
node test-chatgpt.js
node test-animlib.js
node test-v111.js
node test-v112.js
node --check core/main.js && node --check core/config.js && node --check background.js
cd agent && cargo test
```

`test-bridges.js` is a live smoke test: start `PlazCode.exe` first. It checks HTTP `:3000` and WS `17613` / `17615` (no Unreal port).

## Privacy

Everything runs locally. The extension talks only to `127.0.0.1`. No telemetry. AgentScript stays inside the workspace root unless you flip FULL ACCESS.

Optional MCP runtimes are downloaded on first use if no installed runtime is found. They are cached under %LOCALAPPDATA%\PlazCode\runtimes and reused across app updates. The release ZIP contains no Node.js/npm/uv bundle. First use requires internet access.

## Release history

### PlazCode 1.18.91: Desktop work details and responsive status

Expanded desktop work details now show AI replies and commands, with cleaner Home spacing, accurate icons and faster automatic update detection.

- Templates now use Choose a Roblox file and Add template, with short numbered directions. Advanced script search is optional and collapsed.
- Desktop template imports support Roblox files up to 128 MB using direct binary uploads, avoiding base64 copies. Browser imports remain limited to 32 MB; script-index bounds still apply.
- Memory transfer separates Save to a file from Load into another chat, explains saved notes versus messages, and uses clear create/download/load buttons.

- **Added:** Desktop Working/Worked details show AI replies, command text and results from the selected browser chat, loaded only while the panel is open.
- **Improved:** Automatic release checks run every five seconds, with desktop/browser status propagation every two seconds. The default GitHub feed uses a five-second cache key; network/cache delays can still apply. Checks do not overlap.
- **Improved:** DeepSeek and Claude shortcuts use vector logos from the supplied references. Tools uses the supplied icon, and Settings has a symmetric centered gear.
- **Fixed:** Task checkpoints & workflows has a clear gap below the Home cards; the Working panel also has consistent spacing.
- **Fixed:** Expanded work details preserve unchanged content and scrolling across refreshes, collapse once on completion and remain reopenable. Retention is bounded; oversized/older omitted details receive an explicit notice.
- **Fixed:** The updater swirl rotates normally and uses a slower continuous rotation when reduced motion is enabled, instead of freezing.

### PlazCode 1.18.90: Grouped replies and extension status

Task replies and commands collapse together, with extension status under the bar name and a corrected ChatGPT shortcut logo.

- **Added:** The browser bar shows its installed extension version below PlazCode, with green (Up to date), red (Outdated - New update available), or a neutral unavailable/unchecked status.
- **Improved:** The desktop ChatGPT shortcut uses a vector logo traced from the supplied reference instead of a circle character. Its existing browser-opening action is preserved.
- **Fixed:** Working/Worked now includes task prose, final responses, command cards and injected results. Completed groups collapse together and reopen on click. Startup, list_commands/list_tools and PlazCode is ready. remain outside; user requests remain visible.
- **Fixed:** Activity identity survives streaming text changes and transcript remounts, and remains scoped to the chat.

- **Added:** ChatGPT: Highly intelligent in all aspects. DeepSeek: Recommended for free users. Claude: Expert at scripting and game development. Each description appears below its name and above Open in browser.

- The updater explicitly preserves native settings, MCP configuration/enabled servers, memory, pairing, templates, update source and WebView user data, even if a package contains saved-data files.
- The Tools page includes both engine skill libraries, imported Studio helpers, asset_bridge_import and developer-product tools with descriptions.
- Working/Worked uses a centered vector chevron that points right when collapsed and rotates down when expanded.

### PlazCode 1.18.89: Home engine switch

Switch between RobloxScript and AgentScript directly above Start Agent on the desktop Home page.

#### Added

- A themed, keyboard-accessible RobloxScript / AgentScript button group under the active AI status and above Start Agent. The selected engine is highlighted.

#### Improved

- The Home buttons use the existing saved engine preference and browser synchronization, and stay synchronized with the Settings engine selector. Repeated clicks are disabled while saving.

#### Fixed

- Start Agent is temporarily disabled while the engine change is saving or the selected browser chat still reports a different engine, preventing a start on the previous engine.

### PlazCode 1.18.88: Automatic template references

Import Roblox place/model files and let PlazCode find relevant reference systems automatically before a task’s first tool call.

#### Added

- Templates tab in the desktop app and a Template library inside browser Tasks. Import .rbxl, .rbxlx, .rbxm and .rbxmx files up to 32 MB, add a systems description, browse/read scripts and remove saved references.
- Automatic matching uses cached script paths, identifiers and template descriptions. Up to three bounded excerpts are supplied before the first agent tool executes; no explicit “reference this template” request is required.
- Read-only plazcode_templates tools support explicit matching, script lists and paged source reading. Duplicate script paths have separate IDs.
- Open in Studio explicitly opens the retained original through the Windows Roblox file association; select the desired Studio session in PlazCode afterwards.

#### Improved

- Template code is reference data, not executable instructions. Existing project conventions take priority. Matching is a relevance hint rather than guaranteed semantic understanding.
- Template files/indexes persist in your private app data, survive updates and are excluded from distribution ZIPs. Source indexes and excerpts have explicit size limits to avoid flooding long chats.

#### Fixed

- Malformed, unsupported and source-free files report clear import errors. Missing scripts in copied/decompiled games are not fabricated or recovered. Binary and XML imports preserve the original file bytes.

### PlazCode 1.18.87: Task checkpoints, project memory & reliable tools

Review and recover agent tasks, keep project facts separate, and reduce repeated tool errors and long-chat overhead.

#### Added

- Tasks panel in the desktop Home page and browser bar: bounded task history, file before/after previews, conflict-checked Revert and resume in the original chat.
- AgentScript file checkpoints persist across app restarts. Studio Revert is offered only when exact undo records are confirmed in the current bridge/Studio session. Unsupported operations disable whole-task automatic restore.
- Protected paths with explicit task approval; project memory scopes shared by named projects; reusable built-in and custom workflows.

#### Improved

- Long-chat activity retains at most 60 groups, builds collapsed details only when expanded, ignores its own UI mutations and caches unchanged export text. Retention overflow produces an explicit export error.
- Automatic release checks run on launch and every minute; returning to an AI tab or desktop window triggers a throttled check. Update labels refresh without pressing Check now. Network/cache delays can still apply.

#### Fixed

- Tool preflight checks JSON argument shapes against available schemas, detects incomplete Luau strings/delimiters and preserves datamodel defaults. Three consecutive malformed replies or execution failures pause the agent.
- Studio mutation commands are not blindly replayed after a dropped helper connection; uncertain results require inspecting Studio before retrying.
- Unchanged memory and release snapshots no longer generate repeated storage broadcasts. Workflow delivery acknowledgements are deduplicated.

### PlazCode 1.18.86: Reliable bridge port startup

Agent launch reserves every bridge endpoint before reporting ready and serializes overlapping launches.

#### Improvements

- Windows startup is serialized across PlazCode launches; an existing instance of the same version is focused, and older versions are replaced.
- All three required bridge listeners are bound before background services start. Port release is checked with bounded retries instead of fixed delays.

#### Bug fixes

- Removed broad process-name cleanup that could kill another launching PlazCode instance. Recovery only targets a PlazCode process holding a required port.
- Port ownership uses exact endpoint matching, avoiding matches such as port 30000 when checking 3000.
- Startup errors now identify the actual blocked port and, when available, its owning process instead of the generic bridge-bind dialog. Legacy listener failures are logged.

### PlazCode 1.18.85: Wait for app shutdown before updating

The updater waits for PlazCode to exit and release its executable before installing.

#### Improvements

- The updater checks both app executable paths, waits for stopped processes to exit, and briefly retries file-lock checks. Only processes from the selected installation are stopped; Roblox Studio is left running.

#### Bug fixes

- Update installation no longer starts copying immediately after Stop-Process. If the executable remains locked, it aborts before copying any update files and retains recovery files.

### PlazCode 1.18.84: Clickable palettes & friendly readiness

Select desktop themes directly from their color swatches, and keep Notion startup acknowledgements readable.

#### New additions

- Desktop startup instructions accept up to 25,000 characters, with an input counter and explicit save validation.

#### Improvements

- All six desktop color swatches are clickable, keyboard accessible, show the selected theme and use the same saved appearance settings as the dropdown. Glow and gradient preferences are preserved.
- Chat export retains messages captured while scrolling during the current page session. Idle Notion exports briefly load older history and restore the previous scroll position. Exports report their captured message count and remaining scope limitations.
- Download export is styled as a theme-colored button in desktop and browser memory settings.

#### Bug fixes

- All startup instruction variants explicitly request “PlazCode is ready.” instead of a generic readiness sentence.
- If Notion still returns the legacy PLAZCODE_READY token from earlier chat context, its visible acknowledgement is normalized to “PlazCode is ready.” without resending startup or modifying Notion-owned DOM.
- DeepSeek rich-text composers remain discoverable while input-locked, and agent writes temporarily enable editing then restore the lock. Explicit Send labels take precedence over stop-icon guesses.

### PlazCode 1.18.83: Clearer update indicators

Outdated version badges now explicitly say that a new update is available.

#### Improvements

- Desktop, browser bar and popup version badges show “(Outdated - New update available)” when a newer published version is detected. Red highlighting and existing current/unavailable states are preserved.

### PlazCode 1.18.82: Desktop overhaul & smoother Notion sessions

A redesigned desktop workspace, complete color themes and a polished animated updater, with focused Notion and Co-Work improvements.

#### New additions

- A distinct desktop layout: compact navigation, a dedicated agent-session card, AI launch cards, a slim connection strip, and redesigned Tools, MCP, Settings, Terminal and Updates surfaces.
- Animated SVG update swirl with layered rotating arcs, a pulsing center and a redesigned progress dialog. Reduced-motion preferences are respected.
- Expandable Working/Worked summaries in the chat show elapsed time and tool activity; completed details collapse automatically and reopen on click.

#### Improvements

- Themes now color panels, navigation, borders, inputs, buttons, connection surfaces, terminal and update dialogs as well as accents.
- Startup asks the AI to say “PlazCode is ready.”; older readiness acknowledgements remain accepted.
- Co-Work follow-up text uses the website composer’s text color, font, size and alignment. Only the placeholder is grey. Existing queue behavior is preserved.
- Copilot and Meta AI removed from supported-site choices, routing and extension injection.

#### Bug fixes

- Notion can settle a stable readiness acknowledgement without waiting through its nine-second generation tail; live Stop or workflow progress still blocks completion.
- Notion pastes an escaped literal HTML representation alongside plain text so rich-text Markdown conversion does not consume command/result markers. Complete-draft retention and send-confirmation checks remain in place.
- Notion reserves space inside the composer for the PlazCode bar, keeping response text and the native editor clear without modifying React-owned attributes.

### PlazCode 1.18.81: Themes, release notes & desktop refresh

See what each PlazCode update adds, improves and fixes before installing it.

#### New additions

- Release descriptions on the desktop Updates page, including expandable notes for earlier releases.
- The GitHub README now lists release titles, summaries, additions, improvements and fixes.
- An updated maintenance prompt documents architecture, current features, debugging, tests, builds and release publishing.
- Appearance settings with Orange, Amethyst, Polar Cyan, Rose, Emerald and Graphite palettes, glow strength, gradient controls and a default-theme reset. Selections apply immediately and are remembered on this device.
- Version indicators in the desktop, browser bar/menu and extension popup show green “Up to date”, red “Outdated”, or a neutral unavailable/not-checked status. Release checks run at startup and every five minutes.

#### Improvements

- Published update metadata carries the same release notes used in the README.
- Installed release notes remain available before checking online.
- Home places agent controls beside the AI shortcuts on wide windows, reducing unused space; smaller windows stack them neatly.
- The installed-to-latest version arrow is larger, vertically aligned with the version values and spaced more closely.
- Visual-only desktop polish: smoother navigation, card depth, hover and press feedback, keyboard focus, toggles and modal backgrounds. Existing actions and workflows stay the same.
- Quick Actions no longer stretches to match a tall Recent Activity panel; activity stays scrollable.
- A denser desktop layout reduces empty space in status cards and quick actions, with refreshed typography, surfaces and subtle orange highlights.

### PlazCode 1.18.80: Updates, memory transfer & AI shortcuts

Update PlazCode from the desktop app and carry chat context between supported AI sites.

#### New additions

- Desktop Updates tab with installed/latest versions, Check now, Update now, download progress and relaunch.
- ChatGPT, DeepSeek and Claude shortcuts below Home’s connection displays.
- Current-chat memory export and a memory-only export option.

#### Improvements

- Transparent Enhance and Co-Work controls; labels now read Co-Work: Off and Co-Work: On.
- Styled desktop memory import file picker.
- Saved AI memories retain conversation origins after edits, including facts learned in more than one chat.

#### Bug fixes

- Memory-only imports now include saved facts in the destination AI’s context.
- Oversized combined history and memory are rejected before saving or sending.
- View on GitHub opens in the default browser instead of navigating the embedded app.

### PlazCode 1.18.78: Automatic update setup

A stable repository feed lets the update BAT fetch published packages.

#### New additions

- Configured HTTPS update feed hosted in stoveez/PlazCodeneww.

#### Improvements

- Version and SHA256 checks, staged installation, backups and local settings preservation.

#### Bug fixes

- Blank feed settings from 1.18.77 now fall back to the configured repository.

### PlazCode 1.18.77: Shared memory & activity

PlazCode can remember lasting preferences across chats and transfer loaded conversation context.

#### New additions

- Shared personal memory with automatic saving controls and an editable summary.
- Chat history and memory import/export.
- Working/Worked indicators with expandable activity.
- Studio status below the desktop bridge indicator.
- Update-PlazCode.bat with a local ZIP fallback.

#### Improvements

- Saved memory is available across supported provider chats.
- Completed tool activity collapses while final replies remain visible.

