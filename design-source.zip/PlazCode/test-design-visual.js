const fs=require('fs');const {chromium}=require('playwright');
(async()=>{
 const html=fs.readFileSync('agent/src/desktop.html','utf8').replace(/<script>[\s\S]*?<\/script>/g,'');
 const browser=await chromium.launch({headless:true});const page=await browser.newPage();
 await page.setContent(html);
 await page.evaluate(()=>{document.documentElement.dataset.desktopTheme='default';document.documentElement.style.setProperty('--theme-rgb','255 146 38');document.documentElement.style.setProperty('--orange','#ff9226');document.documentElement.style.setProperty('--orange2','#ffc052');});
 fs.mkdirSync('visual-checks',{recursive:true});
 for(const width of [1440,1024,760]){
  await page.setViewportSize({width,height:960});
  for(const name of ['home','settings','tools','creators']){
   await page.evaluate(name=>{document.querySelectorAll('.page').forEach(n=>n.classList.toggle('active',n.id==='page-'+name));},name);
   await page.screenshot({path:`visual-checks/${name}-${width}.png`});
   const overflow=await page.evaluate(()=>{const n=document.getElementById('content');return n.scrollWidth>n.clientWidth+1});
   if(overflow)throw Error(`${name} overflows at ${width}`);
  }
 }
 await page.setViewportSize({width:1440,height:960});
 for(const theme of ['ocean','copper','aurora','orchid','solar']){
  await page.evaluate(theme=>{document.documentElement.dataset.desktopTheme=theme;document.querySelectorAll('.page').forEach(n=>n.classList.toggle('active',n.id==='page-home'));},theme);
  await page.screenshot({path:`visual-checks/theme-${theme}.png`});
 }
 await page.emulateMedia({reducedMotion:'reduce'});
 const motion=await page.locator('.page.active').evaluate(n=>getComputedStyle(n).animationName);if(motion!=='none')throw Error('Reduced motion was ignored');
 await browser.close();console.log('Visual checks: three widths, four pages, five new palettes, reduced motion passed.');
})().catch(e=>{console.error(e);process.exitCode=1});
