const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('core/main.js','utf8');
function extract(start,end){return source.slice(source.indexOf(start),source.indexOf(end,source.indexOf(start)));}
const placeholders=extract('    const followupPlaceholders=', '    function renderCowork()');
function editor(placeholder='Message DeepSeek'){const attrs=new Map([['placeholder',placeholder]]);return {tagName:'TEXTAREA',getAttribute:key=>attrs.has(key)?attrs.get(key):null,setAttribute:(key,value)=>attrs.set(key,value),removeAttribute:key=>attrs.delete(key),attrs};}
const ctx={};vm.createContext(ctx);vm.runInContext(placeholders+'globalThis.setPh=setFollowupPlaceholder;',ctx);
const a=editor(),b=editor('Ask AI');ctx.setPh(a,true);assert.equal(a.getAttribute('placeholder'),'Follow up');ctx.setPh(b,true);assert.equal(a.getAttribute('placeholder'),'Message DeepSeek');assert.equal(b.getAttribute('placeholder'),'Follow up');ctx.setPh(b,false);assert.equal(b.getAttribute('placeholder'),'Ask AI');
let text='Add a door',queued=[],cleared=0,pumped=0;
const box={A:{started:true},P:{editorText:()=>text,writeDraft:async(value,expected)=>{assert.equal(text,expected);text=value;cleared++;return {ok:true};}},cowork:{snapshot:()=>({enabled:true}),enqueue:request=>{queued.push(request);return{ok:true};}},ui:{toast:message=>{throw Error(message);}},pumpCowork:()=>pumped++,Promise};
vm.createContext(box);vm.runInContext('globalThis.send='+extract('    onCoworkSend: event => {','    isBlocked:').trim().replace(/^onCoworkSend: /,'').replace(/,$/,'')+';',box);
const event={isTrusted:true,preventDefault(){this.prevented=true;},stopImmediatePropagation(){this.stopped=true;}};
(async()=>{assert.equal(box.send(event),true);assert.deepEqual(queued,['Add a door']);assert(event.prevented&&event.stopped);await box.A.coworkDraftWrite;assert.equal(text,'');assert.equal(cleared,1);assert.equal(pumped,1);box.A.injecting=true;text='Leave my text';assert.equal(box.send(event),false);assert.equal(text,'Leave my text');assert.equal(box.send({...event,isTrusted:false}),false);
for(const name of ['deepseek','chatgpt','claude','notion']){const provider=fs.readFileSync('providers/'+name+'.js','utf8');assert(provider.includes('onCoworkSend(e)'));assert(provider.includes('writeDraft'));}
assert(!source.includes('cover.innerHTML = `<span id="rs-working-label">Agent is working…</span><div'));
console.log('Native Co-work uses original composer, restores placeholders on mode/editor change, accepts follow-ups immediately, clears verified drafts, and excludes automated injection events.');})().catch(e=>{console.error(e);process.exitCode=1;});
