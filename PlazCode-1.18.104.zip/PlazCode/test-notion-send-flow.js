const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict'),{JSDOM}=require(process.env.PLAZCODE_TEST_JSDOM||'jsdom');
const source=fs.readFileSync('providers/notion.js','utf8');
(async()=>{for(const mode of ['ROBLOXSCRIPT','AGENTSCRIPT']){
 const dom=new JSDOM('<main><section id="composer"><div role="textbox" contenteditable="true" data-placeholder="Ask Notion AI"></div><div role="button" data-testid="agent-chat-send-button" aria-label="Submit AI message">Send</div></section></main>',{url:'https://app.notion.com/ai',runScripts:'outside-only',pretendToBeVisual:true}),w=dom.window,ed=w.document.querySelector('[role=textbox]'),button=w.document.querySelector('[role=button]');
 let model='',pastes=0,commits=0,edits=0,stopped=false,reject=false;const delivered=[];
 w.HTMLElement.prototype.getBoundingClientRect=function(){return {left:200,top:600,width:650,height:this===ed?40:100,right:850,bottom:700};};
 class Transfer{constructor(){this.data={};}setData(k,v){this.data[k]=v;}getData(k){return this.data[k]||'';}}
 class Paste extends w.Event{constructor(type,o){super(type,o);this.clipboardData=o.clipboardData;}}
 w.DataTransfer=Transfer;w.ClipboardEvent=Paste;
 ed.addEventListener('paste',e=>{e.preventDefault();pastes++;const holder=w.document.createElement('div');holder.innerHTML=e.clipboardData.getData('text/html');assert(holder.querySelector('pre code'));model=reject?'':holder.textContent;ed.textContent=model;});
 w.document.execCommand=(_,__,value)=>{edits++;assert(value.length<2500,'No bulk execCommand');model=value;ed.textContent=value;return true;};
 button.addEventListener('click',()=>{commits++;delivered.push(model);model='';ed.textContent='';const row=w.document.createElement('div');row.setAttribute('data-agent-service-scroll-anchor','user-'+commits);row.style.justifyContent='flex-end';row.textContent=delivered.at(-1);w.document.body.append(row);w.provider.invalidateItems();w.history.replaceState({},'','/chat/test-'+mode);});
 try{vm.runInContext(source+';globalThis.provider=RSProvider;',dom.getInternalVMContext());const p=w.provider;p.init({isStopped:()=>stopped});p.setInputLock(true);assert.equal(p.coverTarget(),ed);assert.equal(w.document.body.getAttribute('contenteditable'),null);
 const startup='⟦RS-SYS⟧ '+mode+'\n'+('Keep literal **names** C:\\Exact\\File 🧠\n').repeat(20)+'\nEmit list_commands first.';
 assert((await p.prepareSessionStart('startup')).ready);assert(await p.typeAndSend(startup));assert.equal(delivered[0],startup);assert.equal(pastes,1);assert.equal(edits,0);assert.equal(commits,1);
 const result="Output of 'list_commands':\n"+'read_script {}\n'.repeat(20);assert(await p.typeAndSend(result));assert.equal(delivered[1],result);assert.equal(commits,2);assert.equal(edits,0);p.setInputLock(false);assert.equal(p.getEditor(),ed);assert.equal(ed.getAttribute('contenteditable'),'true');
 const fresh=w.document.createElement('a');fresh.href='/ai';fresh.textContent='New AI chat';fresh.addEventListener('click',event=>{event.preventDefault();w.document.querySelectorAll('[data-agent-service-scroll-anchor]').forEach(row=>row.remove());w.history.replaceState({},'','/ai');p.invalidateItems();});w.document.body.append(fresh);assert((await p.prepareSessionStart('startup')).navigating);assert.equal(w.location.pathname,'/ai');assert((await p.prepareSessionStart('startup')).ready);assert.equal(commits,2);
 stopped=true;const old=pastes;assert.equal(await p.typeAndSend(startup),false);assert.equal(pastes,old);stopped=false;w.history.replaceState({},'','/p/document');assert.equal(await p.typeAndSend(startup),false);assert.equal(pastes,old);
 w.history.replaceState({},'','/ai');reject=true;p.setInputLock(true);const before=commits;assert.equal(await p.typeAndSend('x'.repeat(33035),null,{retryDelayMs:1,protocolFile:true}),false);assert.equal(commits,before);assert.equal(edits,0);p.setInputLock(false);
 console.log(mode+': actual provider delivers inline startup and catalogue with one paste/click each, rejects hydration/Stop/document writes, keeps editor and cover scoped.');
 }finally{w.close();}
}})().catch(e=>{console.error(e);process.exitCode=1;});
