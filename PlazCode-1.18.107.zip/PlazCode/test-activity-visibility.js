const assert = require('assert');
const {JSDOM} = require(process.env.PLAZCODE_TEST_JSDOM || 'jsdom');
const dom = new JSDOM('<main><article>Original reply</article></main>');
global.document = dom.window.document;
const Activity = require('./core/activity.js');
const activity = Activity.create();
activity.sync(true, 'chat', 1);
const group = activity.active(), item = document.querySelector('article');
activity.record(group.id, 'reply', 'assistant', item.textContent);
activity.sync(false, 'chat', 2000);
let fail = true, placement = 0;
const renderer = Activity.renderer({
  label: g => activity.label(g), toggle: id => activity.toggle(id),
  mount(anchor, node) {
    if (fail) throw new Error('Provider surface temporarily unavailable');
    anchor.before(node);
    return {place() { placement++; }, dispose() { node.remove(); }};
  },
});
assert.equal(renderer.sync([group], () => item).size, 0);
fail = false;
assert(renderer.sync([group], () => item).has(group.id));
assert.equal(placement, 1, 'Collapsed headings must still be placed');
assert.equal(document.querySelector('button').getAttribute('aria-expanded'), 'false');
document.querySelector('button').click();
assert(group.expanded);
renderer.sync([group], () => item);
assert.equal(document.querySelector('button').getAttribute('aria-expanded'), 'true');
item.remove();
assert.equal(renderer.sync([group], () => item).size, 0);
assert(document.querySelector('.rs-chat-activity').hidden);
activity.sync(true, 'chat', 3000);
const interrupted = activity.active();
activity.sync(false, 'chat', 4000, {collapse: false});
assert(interrupted.expanded);
assert(group.messages.some(message => message.text === 'Original reply'));
console.log('Interrupted work remains expanded; unavailable headings fail open, retry mounting, and place collapsed summaries. Original messages are retained.');
